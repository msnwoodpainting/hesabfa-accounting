# مرجع کامل متدهای API حسابفا

> نحوه خواندن این فایل: هنگامی که لازم است مشخصات دقیق یک متد را بدانی (مسیر، پارامترها، پاسخ)، این فایل را با `skill_view("hesabfa-accounting", "references/api-reference.md")` بارگذار کن. ساختار اشیای JSON در `references/objects.md` و جداول enum و کدهای خطا در `references/enums-errors.md` است.

## قراردادهای عمومی

- **Base URL:** `https://api.hesabfa.com/v1/`
- **همه درخواست‌ها POST** با `Content-Type: application/json` هستند (هیچ GET/PUT/DELETE وجود ندارد).
- **بدنه درخواست:** یک شیء JSON تخت که کلیدهای `apiKey`، `loginToken` (یا `userId` + `password`)، و پارامترهای متد کنار هم قرار دارند.
- **پاکت پاسخ (همیشه):** `{"Success": bool, "ErrorCode": int, "ErrorMessage": str, "Result": ...}` — فقط وقتی HTTP 200 است.
- **محدودیت نرخ:** حداکثر ۱۲۰ درخواست در دقیقه؛ خطای 101 یعنی صبر حداقل ۱۰ ثانیه (CLI خودش یک بار تلاش مجدد می‌کند).
- **تاریخ‌ها:** میلادی ISO (`2025-11-14`)؛ CLI خودش تاریخ شمسی ورودی را تبدیل می‌کند و «امروز» را به وقت تهران حل می‌کند (تست زنده ۱۴۰۵/۰۸/۲۴).
- **`yearId`:** انتخاب سال مالی (۱ = سال اول). اگر ارسال نشود آخرین سال مالی استفاده می‌شود.
- **`requestUniqueId`:** کلید idempotency (GUID) فقط برای متدهای ثبت/حذف؛ ۲۴ ساعت معتبر؛ تکرار آن خطای 120 می‌دهد (پرچم `--idempotency` در CLI).
- **صفحه‌بندی:** متدهای لیست، `queryInfo` می‌گیرند (توضیح کامل در `references/enums-errors.md`) — اگر `take` ندهی سرور فقط ۱۰ رکورد برمی‌گرداند (CLI پیش‌فرض ۲۰ می‌فرستد).

## فهرست کامل ۹۲ متد

همه مسیرها POST به `https://api.hesabfa.com/v1/<مسیر>` هستند. پارامترهای ستون «بدنه» علاوه بر فیلدهای احراز هویت است. علامت `*` یعنی الزامی.

### اشخاص (Contact) — ۷ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `contact/get` | دریافت یک شخص با کد | `code` |
| `contact/getById` | دریافت با شناسه(های) داخلی | `idList` (آرایه) |
| `contact/getContacts` | لیست صفحه‌بندی‌شده | `queryInfo` |
| `contact/save` | ثبت/ویرایش شخص | `contact` (شیء — `objects.md`) |
| `contact/batchSave` | ثبت گروهی | `contacts` (آرایه شیء) |
| `contact/delete` | حذف شخص | `code` |
| `contact/getContactLink` | لینک عمومی کارت حساب شخص | `code`, `showAllAccounts` (پیش‌فرض false), `days` (اعتبار لینک، پیش‌فرض ۳۰) |

دستورهای CLI: `contact list | get | getbyid | save | batchsave | delete | ledgerlink`

> **یافته تست زنده (۱۴۰۵/۰۸/۲۴):** سرور فیلد `contactType` را در save نادیده می‌گیرد و نوع شخص را از پر بودن فیلد `company` نتیجه می‌گیرد (شرکت پر ⇒ حقوقی/۲). برای شخص حقوقی حتماً `company` را بفرست.

### کالا و خدمات (Item) — ۱۰ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `item/get` | دریافت کالا با کد | `code` |
| `item/getByBarcode` | دریافت با بارکد | `barcode` |
| `item/getById` | دریافت با شناسه | `idList` |
| `item/getItems` | لیست صفحه‌بندی‌شده | `queryInfo` |
| `item/save` | ثبت/ویرایش کالا/خدمت | `item` (شیء — `objects.md`) |
| `item/batchSave` | ثبت گروهی | `items` (آرایه) |
| `item/delete` | حذف | `code` |
| `item/GetQuantity` | موجودی کالاها | `warehouseCode` (اختیاری), `codes` (اختیاری، حداکثر ۲۰۰۰ کد) |
| `item/GetQuantity2` | موجودی + تفکیک انبار | `codes` (اختیاری، حداکثر ۲۰۰۰) |
| `item/UpdateOpeningQuantity` | به‌روزرسانی موجودی اول دوره | `items[]` با `*code`, `*quantity` (>0), `*unitPrice` (>0), `warehouseCode` |

دستورهای CLI: `item list | get | getbybarcode | getbyid | save | batchsave | delete | quantity | quantity2 | opening-quantity`

### فاکتور (Invoice) — ۱۰ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `invoice/get` | دریافت فاکتور | `number`, `type` (invoiceType) |
| `invoice/getById` | دریافت با شناسه | `id` و/یا `idList` |
| `invoice/getInvoices` | لیست صفحه‌بندی‌شده | `type` *, `queryInfo` |
| `invoice/save` | ثبت/ویرایش فاکتور | `invoice` (شیء — `objects.md`) |
| `invoice/delete` | حذف فاکتور | `number`, `type` |
| `invoice/savePayment` | ثبت دریافت/پرداخت فاکتور | `type`, `number`, یکی از `bankCode`/`cashCode`/`pettyCashCode`, `contactCode`, `date`, `amount` *, `transactionNumber` *, `transactionFee`, `project`, `description`, `currency`, `currencyRate` |
| `invoice/getOnlineInvoiceUrl` | لینک فاکتور آنلاین | `number`, `type` |
| `invoice/SaveWarehouseReceipt` | ثبت حواله انبار برای فاکتور | `deleteOldReceipts`, `receipt` با `*warehouseCode`, `*invoiceNumber`, `*invoiceType`, `date`, `notes`, `freight`, `delivery`, `project`, `*items[]` (`*itemCode`, `*quantity`) — جهت رسید/حواله از نوع فاکتور مشخص می‌شود |
| `invoice/changePaidStatus` | تغییر وضعیت پرداخت | `number`, `type`, `paid` (bool) |
| `invoice/changeSentStatus` | تغییر وضعیت ارسال | `number`, `type`, `sent` (bool) |

دستورهای CLI: `invoice list | get | getbyid | save | delete | save-payment | online-url | save-warehouse-receipt | change-paid-status | change-sent-status`

نکته مهم `invoice/save`: اگر `number` را ندهی شماره خودکار می‌گیرد؛ اگر بدهی و وجود داشته باشد ویرایش می‌شود و اگر وجود نداشته باشد با همان شماره ثبت می‌شود. همین منطق برای `code` اشخاص و کالاها برقرار است.

### دریافت و پرداخت (Receipt) — ۶ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `receipt/get` | دریافت رسید | `type` (receiptType), `number` |
| `receipt/GetById` | دریافت با شناسه | `type`, `id` و/یا `idList` |
| `receipt/getReceipts` | لیست صفحه‌بندی‌شده | `type` *, `queryInfo` |
| `receipt/save` | ثبت ساده (یک طرف حساب + یک منبع) | `type` *, `number`, `dateTime`, `project`, `description`, یکی از `bankCode`/`cashCode`/`pettyCashCode`, `accountPath`, `contactCode`, `amount` *, `bankFee`, `reference`, `currency`, `currencyRate` — نوع‌های 1/2 با `contactCode` و نوع‌های 3/4 با `accountPath` |
| `receipt/save2` | ثبت پیشرفته (چند قلم + چک) | `type` *, `number`, `description`, `currency`, `currencyRate`, `dateTime`, `project`, `items[]` (`account` یا `contactCode`, `amount` *, `description`), `transactions[]` (`amount` *, منبع: `bankCode`/`cashCode`/`pettyCashCode`/`contactCode`/`account`/`check`/`spendCheck`, `reference`, `transactionFee`) — جزئیات چک در `objects.md` |
| `receipt/delete` | حذف رسید | `type`, `number` |

دستورهای CLI: `receipt list | get | getbyid | save | save2 | delete`

### انبار (Warehouse) — ۵ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `warehouse/get` | دریافت رسید/حواله انبار | `number` |
| `warehouse/GetById` | دریافت با شناسه | `id` و/یا `idList` |
| `warehouse/getReceipts` | لیست | `type` (۱ رسید ورود / ۲ حواله خروج) *, `queryInfo` |
| `warehouse/save` | ثبت رسید/حواله انبار آزاد | `deleteOldReceipts`, `receipt` با `number`, `invoiceNumber`, `*invoiceType`, `warehouseCode`, `destinationWarehouseCode` (انتقال بین انبار), `date`, `notes`, `delivery`, `freight`, `project`, `receiving` (true=ورود/false=خروج), `items[]` (`itemCode`, `quantity`, `reference`, `notes`) |
| `warehouse/delete` | حذف | `number` |

دستورهای CLI: `warehouse list | get | getbyid | save | delete`

### سند حسابداری (Document) — ۴ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `document/get` | دریافت سند | `number` |
| `document/getDocuments` | لیست اسناد | `queryInfo` |
| `document/save` | ثبت سند دستی دوطرفه | `document` با `number`, `reference`, `date`, `description`, `project`, `debit`, `credit`, `status`, `transactions[]` (سطرهای سطر کل — `objects.md`) |
| `document/delete` | حذف سند | `number` |

دستورهای CLI: `document list | get | save | delete`

سند باید تراز باشد (جمع بدهکار = جمع بستانکار).

### اقلام تخفیف‌دار (Discount) — ۶ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `disCountItem/get` | دریافت با فیلتر | `contactCode`, `productCode`, `contactPath`, `productPath`, `tag` (همه اختیاری) |
| `disCountItem/getById` | دریافت با شناسه | `idList` |
| `disCountItem/getItems` | لیست | `queryInfo` |
| `disCountItem/save` | ثبت تخفیف | `item`: `title` *, `type` *, `percent`, `amount`, `validFrom`, `validTo`, `tag` |
| `disCountItem/batchSave` | ثبت گروهی | `items[]` (+ `contactPath`) |
| `disCountItem/delete` | حذف | `idList` |

دستورهای CLI: `discount list | get | getbyid | save | batchsave | delete`

### انتقال بین بانکی (BankTransfer) — ۴ متد

| مسیر | کار | بدنه درخواست |
|---|---|---|
| `bankTransfer/get` | دریافت انتقال | `number` |
| `bankTransfer/getTransfers` | لیست | `queryInfo` |
| `bankTransfer/save` | ثبت انتقال | `transfer`: `number`, `description`, `project`, `date`, `fromAmount`, `fromReference`, منبع مبدأ (`fromBank`/`fromCash`/`fromPettyCash`), `fromTransactionFee`, `fromCurrencyRate`, `toAmount`, `toReference`, منبع مقصد (`toBank`/`toCash`/`toPettyCash`), `toTransactionFee`, `toCurrencyRate` |
| `bankTransfer/delete` | حذف | `number` |

دستورهای CLI: `banktransfer list | get | save | delete`

### تنظیمات (Setting) — ۱۸ متد + هوک

| مسیر | کار | پارامترها |
|---|---|---|
| `setting/getChanges` | فید آخرین تغییرات | `start` (آخرین Id دیده‌شده) |
| `setting/getFiscalYears` | لیست سال‌های مالی | — |
| `setting/getFiscalYear` | سال مالی جاری | — |
| `setting/getBanks` | لیست بانک‌ها | — |
| `setting/getCashes` | لیست صندوق‌ها | — |
| `setting/getPettyCashes` | لیست تنخواه‌گردان‌ها | — |
| `setting/GetCurrency` | واحد پول پیش‌فرض | — |
| `setting/getWarehouses` | لیست انبارها | — |
| `setting/getProductCategories` | درخت دسته‌بندی کالاها | — |
| `setting/getServiceCategories` | درخت دسته‌بندی خدمات | — |
| `setting/getContactCategories` | درخت دسته‌بندی اشخاص | — |
| `setting/getProjects` | لیست پروژه‌ها | — |
| `setting/getSalesmen` | لیست فروشندگان/بازاریابان | — |
| `setting/getCurrencyTable` | جدول نرخ ارزها | — |
| `setting/setCurrencyTable` | ذخیره نرخ ارزها | `table[]` با `{from, to, rate}` |
| `setting/getAccounts` | جدول حساب‌ها (کدینگ) | — |
| `setting/getDefaultPriceList` | لیست‌های قیمت پیش‌فرض | — |
| `setting/getBusinessInfo` | اطلاعات کسب‌وکار و اشتراک | — |
| `setting/SetChangeHook` | تنظیم وب‌هوک تغییرات | `url` (فقط HTTPS؛ رشته خالی = حذف), `hookPassword`, `index` (1/2/3) |
| `setting/GetChangeHook` | مشخصات هوک‌ها | — |

دستورهای CLI: `setting changes | fiscal-years | fiscal-year | banks | cashes | petty-cashes | currency | warehouses | product-categories | service-categories | contact-categories | projects | salesmen | currency-table | set-currency-table | accounts | price-lists | business-info | set-change-hook | get-change-hook`

**وب‌هوک:** تغییرات فاکتور/کالا/اشخاص که «داخل نرم‌افزار» انجام شوند بلافاصله POST می‌شوند (هدر `User-Agent: Hesabfa-Webhook/1.0`)؛ تغییرات انجام‌شده از طریق خود API push نمی‌شوند. بدنه: `{"Password": "...", "Action": 52, "ObjectType": "Product", "ObjectIdList": [1,2,3]}`. احراز اصالت با `hookPassword`.

**فید تغییرات (`getChanges`):** آرایه‌ای از `{Id, DateTime, Action, ObjectId, ObjectType, Extra, Extra2, API}` — `ObjectType` یکی از Product/Contact/Invoice/WarehouseReceipt/Receipt/Document؛ `Extra` کد کالا/شخص (یا کد اقلام فاکتور) و در حذف، کد شیء حذف‌شده؛ `Extra2` شماره فاکتور؛ `API` می‌گوید تغییر از طریق API رخ داده. برای همگام‌سازی دوره‌ای، آخرین `Id` را ذخیره کن و دوباره با `start` بپرس.

### گزارش‌ها (Report) — ۱۰ متد

همه `startDate`, `endDate`, `project` (اختیاری) می‌گیرند؛ تاریخ‌ها میلادی ISO.

| مسیر | کار | پارامتر اضافه |
|---|---|---|
| `report/balanceSheet` | ترازنامه | — |
| `report/debtorsCreditors` | بدهکاران و بستانکاران | — |
| `report/inventory` | موجودی کالا | — |
| `report/profitandlossStatement` | صورت سود و زیان | — |
| `report/trialBalance` | تراز آزمایشی | — |
| `report/trialBalanceItems` | تفصیل تراز آزمایشی | `accountPath` * |
| `report/bank` | گردش حساب بانک | `code` (کد بانک) * |
| `report/cash` | گردش حساب صندوق | `code` * |
| `report/pettyCash` | گردش تنخواه‌گردان | `code` * |
| `report/journal` | دفتر روزنامه | `take` (پیش‌فرض/حداکثر ۱۰۰۰), `skip` |

دستورهای CLI: `report balance-sheet | debtors-creditors | inventory | profit-loss | trial-balance | trial-balance-items | bank | cash | petty-cash | journal`

نکات تست زنده (۱۴۰۵/۰۸/۲۴):
- در پاسخ `report/journal` ممکن است `FilteredCount` صفر باشد حتی وقتی `List` پر است — به `List` تکیه کن.
- سطرهای `report/trialBalance` فیلد `Account{Path, Name, AccountType, MainAccountType}` دارند (نه `AccountPath`)؛ رکوردهای گروهی (جمع‌ها) `Account` خالی دارند.

ساختار پاسخ هر گزارش در `references/objects.md` §گزارش‌ها آمده است.

### سیستم استعلام (Inquiry) — ۱۰ متد (مصرف توکن دارد)

پاسخ همه: `Result = {Status, Message, Data{...}}`؛ توکن باقیمانده: `inquiry/credit`.

| مسیر | کار | پارامترها |
|---|---|---|
| `inquiry/credit` | توکن باقیمانده | — |
| `inquiry/nationalIdentity` | استعلام کد ملی | `nationalCode` *, `birthDate` * |
| `inquiry/checkMobileAndNationalCode` | تطابق موبایل و کد ملی | `nationalCode` *, `mobile` * |
| `inquiry/checkCardAndNationalCode` | تطابق کارت و کد ملی | `nationalCode` *, `cardNumber` *, `birthDate` * |
| `inquiry/checkIbanAndNationalCode` | تطابق شبا و کد ملی | `nationalCode` *, `iban` *, `birthDate` * |
| `inquiry/iban` | استعلام شبا | `iban` * |
| `inquiry/card` | استعلام کارت | `cardNumber` * |
| `inquiry/cardToIban` | تبدیل کارت به شبا | `cardNumber` * |
| `inquiry/accountToIBAN` | تبدیل حساب به شبا | `account` *, `bank` (کد بانک — جدول در enums) * |
| `inquiry/postalCode` | استعلام کد پستی | `postalCode` * |

دستورهای CLI: `inquiry credit | national-identity | mobile-national-code | card-national-code | iban-national-code | iban | card | card-to-iban | account-to-iban | postal-code`

### متد خام برای هر متد بدون دستور اختصاصی

```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" call <مسیر-متد> --data '{"code":"0001"}' --api-key KEY --login-token TOKEN
```

با `call` هر ۹۲ متد بدون استثنا قابل فراخوانی است؛ `--data` می‌تواند رشته JSON، `@فایل.json` یا `-` (stdin) باشد.
