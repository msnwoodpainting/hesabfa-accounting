# دستورالعمل‌های عملیاتی (Recipe ها)

> گردش‌کارهای رایج حسابداری با حسابفا به ترتیب اجرا. قبل از اجرا مطمئن شو کلیدها را داری (بخش «اعتبارنامه» در SKILL.md). تمام دستورها با `--dry-run` قابل پیش‌بررسی هستند.

فهرست:
1. ثبت فاکتور فروش کامل (مشتری + کالا + فاکتور + پرداخت + حواله انبار)
2. ثبت فاکتور خرید و پرداخت تامین‌کننده
3. ثبت دریافت با چک (دریافتی و خرج چک)
4. ثبت سند حسابداری دستی
5. استعلام‌های هویتی و بانکی
6. همگام‌سازی داده‌ها (getChanges و وب‌هوک)
7. گزارش‌گیری مالی دوره
8. انتقال بین بانک/صندوق و مدیریت موجودی

---

## ۱. ثبت فاکتور فروش کامل

**گام ۱ — بررسی یا ثبت مشتری:**
```bash
# جستجوی مشتری بر اساس نام (--search خودکار به فلتر Name:* تبدیل می‌شود)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" contact list --search "نام-مشتری" --api-key $K --login-token $T
# اگر نبود، ثبت کن — برای شخص حقوقی حتماً --company را پر کن (سرور نوع را از company می‌گیرد)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" contact save --name "شرکت آریا" --company "شرکت آریا" --contact-type حقوقی --is-customer --mobile 09121234567 --node-family "اشخاص:اشخاص حقوقی:مشتریان" --api-key $K --login-token $T
```
کد مشتری را از پاسخ (`Result.Code`) بردار.

**گام ۲ — بررسی یا ثبت کالا/خدمت:**
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" item list --search "کابل" --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" item save --name "کابل شبکه Cat6" --item-type کالا --sell-price 950000 --node-family "کالاها:لوازم شبکه" --api-key $K --login-token $T
```

**گام ۳ — ثبت فاکتور فروش** (برای فاکتور چند-اقلامی فایل JSON بساز و `--file` بده):
```json
{ "date": "1404/08/23", "dueDate": "1404/09/23", "contactCode": "0001",
  "invoiceType": "فروش", "status": 1,
  "invoiceItems": [{"itemCode": "K001", "description": "کابل شبکه Cat6", "quantity": 2, "unitPrice": 950000, "discount": 100000, "tax": 90000}] }
```
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" invoice save --file /tmp/invoice.json --api-key $K --login-token $T
```
شماره فاکتور از `Result.Number` (اگر number ندی شماره خودکار می‌گیرد).

**گام ۴ — ثبت دریافت:** راه پیشنهادی برای وصول فاکتور، `invoice save-payment` است — قید را درست به «حساب‌های دریافتنی» می‌زند و `Paid` فاکتور را صفر می‌کند (تست زنده ۱۴۰۵/۰۸/۲۴: رسید مستقل ممکن است به «حساب های پرداختنی» بستانکار شود):
```bash
# راه درست برای تسویه فاکتور (transactionNumber الزامی است)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" invoice save-payment --number 101 --type فروش --amount 1890000 --transaction-number TRX-889 --bank-code 0001 --date 1404/08/23 --api-key $K --login-token $T
# یا رسید مستقل (بدون لینک به فاکتور — بابت مشتری ممکن است به پرداختنی برود؛
# در صورت نیاز --account-path بده و در پاسخ Items[].Account را چک کن)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" receipt save --type دریافت --amount 1890000 --contact-code 0001 --bank-code 1 --description "واریز بابت فاکتور 101" --api-key $K --login-token $T
```
کد بانک/صندوق را از `setting banks`/`setting cashes` بگیر (مثل 0001).

**گام ۵ — حواله انبار** (فقط فاکتور کالایی، نه خدماتی):
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" invoice save-warehouse-receipt --warehouse-code 1 --invoice-number 101 --invoice-type فروش --items-json '[{"itemCode":"K001","quantity":2}]' --api-key $K --login-token $T
```

**گام ۶ — تحقق و لینک فاکتور آنلاین:**
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" invoice get --number 101 --type فروش --api-key $K --login-token $T --result
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" invoice online-url --number 101 --type فروش --api-key $K --login-token $T
```

## ۲. ثبت فاکتور خرید و پرداخت تامین‌کننده

همان گردش فروش با تفاوت‌ها: `invoiceType: خرید` (۱)، شخص تامین‌کننده (`isVendor: true`)، خرید کالا با `buyPrice`، و پرداخت با نوع رسید 2:
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" receipt save --type پرداخت --amount 5000000 --contact-code 0002 --bank-code 1 --description "پرداخت به تامین‌کننده" --api-key $K --login-token $T
```
برای فاکتور برگشت از خرید، `invoiceType: برگشت از خرید` (۳) و حواله انبار جهت ورود می‌گیرد.

## ۳. ثبت دریافت با چک

**چک دریافتی** (`receipt/save2` — چک یکی از transactions است):
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" receipt save2 --type دریافت \
  --items-json '[{"contactCode":"0001","amount":2000000,"description":"چک بابت فاکتور 101"}]' \
  --transactions-json '[{"amount":2000000,"check":{"number":"5470098","date":"1404/09/01","amount":2000000,"sayyad":"872000545448792","bankName":"تجارت","payerCode":1}}]' \
  --api-key $K --login-token $T
```
- برای چک دریافتی: `bankName` (نام بانک صادرکننده) و `payerCode` لازم است؛ برای چک پرداختی: `payee` (در وجه) و `bankCode`.
- `sayyad` شماره رهگیری ۲۴ رقمی سامانه صیاد است — اگر کاربر ندارد، خالی بگذار و یادداشت کن.

**خرج چک** (چک دریافتی را به‌جای وصول خرج کن):
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" receipt save2 --type پرداخت \
  --items-json '[{"contactCode":"0002","amount":2000000,"description":"پرداخت به تامین‌کننده با خرج چک"}]' \
  --transactions-json '[{"amount":2000000,"spendCheck":{"number":"5470098","date":"1404/09/05","amount":2000000}}]' \
  --api-key $K --login-token $T
```

وضعیت چک‌های دریافتی از پاسخ `receipt get` (فیلد `Transactions[].Check.Status`) خوانده می‌شود؛ فهرست مقادیر Status در مستندات رسمی منتشر نشده — مقدار خام را گزارش کن.

## ۴. ثبت سند حسابداری دستی

قبل از ثبت، کدینگ را از جدول حساب‌ها بگیر و `accountPath` را **دقیقاً** با همان متن کپی کن:
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" setting accounts --api-key $K --login-token $T --result
```
سند دوطرفه (فایل JSON):
```json
{ "date": "1404/08/23", "description": "ثبت هزینه اجاره آبان", "status": 1,
  "transactions": [
    {"accountPath": "هزینه ها:هزینه های اداری و عمومی:هزینه اجاره", "amount": 20000000, "type": 0, "description": "اجاره آبان 1404"},
    {"accountPath": "دارایی ها:دارایی های جاری:بانک", "amount": 20000000, "type": 1, "description": "پرداخت از بانک", "bankCode": "1"} ] }
```
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" document save --file /tmp/doc.json --api-key $K --login-token $T
```
قبل از ارسال، جمع `type:0` را با جمع `type:1` مقایسه کن (باید مساوی باشند). سند را بعد از ثبت با `document get --number ...` تحقق بده.

## ۵. استعلام‌های هویتی و بانکی

```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" inquiry credit --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" inquiry national-identity --national-code 0012345678 --birth-date 1375/10/11 --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" inquiry iban --iban IR120120000000001234567890 --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" inquiry account-to-iban --account 1234567890 --bank 012 --api-key $K --login-token $T
```
استعلام‌ها توکن مصرف می‌کنند — اول `inquiry credit` را بگیر و به کاربر اطلاع بده. پاسخ در `Result.Data` است و `Result.Status` موفقیت استعلام را نشان می‌دهد.

## ۶. همگام‌سازی داده‌ها

**روش polling با getChanges** — آخرین Id پردازش‌شده را نگه دار:
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" setting changes --start 1337 --api-key $K --login-token $T --result
```
هر تغییر: `{Id, DateTime, Action, ObjectId, ObjectType, Extra, Extra2, API}`. `Action` های حذف همیشه با «3» تمام می‌شوند (۱۳۳ = حذف فاکتور فروش). برای هر ObjectId مشخص، رکورد را با متد get همان ماژول بگیر. تغییراتی که خودت با API انجام داده‌ای هم در فید می‌آیند (فیلد `API: true`) — از حلقه بی‌نهایت جلوگیری کن.

**وب‌هوک (push):** فقط برای تغییرات ثبت‌شده داخل خود نرم‌افزار فایر می‌شود؛ URL باید HTTPS معتبر داشته باشد:
```bash
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" setting set-change-hook --url "https://example.com/hook" --hook-password "رمز-دلخواه" --index 1 --api-key $K --login-token $T
```
حذف: همان دستور با `--url ""`. بدنه ورودی: `{Password, Action, ObjectType, ObjectIdList}` با هدر `User-Agent: Hesabfa-Webhook/1.0`.

## ۷. گزارش‌گیری مالی دوره

```bash
# تراز آزمایشی دوره
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report trial-balance --start-date 1404/01/01 --end-date 1404/08/29 --api-key $K --login-token $T --result
# دفتر روزنامه (صفحه‌ای؛ حداکثر ۱۰۰۰ سطر در هر درخواست)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report journal --start-date 1404/08/01 --end-date 1404/08/29 --take 1000 --api-key $K --login-token $T --result
# گردش بانک و بدهکاران/بستانکاران
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report bank --code 1 --start-date 1404/08/01 --end-date 1404/08/29 --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report debtors-creditors --start-date 1404/01/01 --end-date 1404/08/29 --api-key $K --login-token $T
# ترازنامه و سود و زیان
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report balance-sheet --start-date 1404/01/01 --end-date 1404/08/29 --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" report profit-loss --start-date 1404/01/01 --end-date 1404/08/29 --api-key $K --login-token $T
```
کد بانک/صندوق برای گزارش گردش را از `setting banks` / `setting cashes` بگیر. اگر کاربر تاریخ شمسی گفت، همان را بده — CLI خودش تبدیل می‌کند.

## ۸. انتقال بین بانک/صندوق و مدیریت موجودی

```bash
# انتقال بین بانکی
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" banktransfer save --from-bank 1 --to-cash 1 --from-amount 2000000 --to-amount 2000000 --date 1404/08/23 --description "انتقال از بانک به صندوق" --api-key $K --login-token $T
# موجودی کالا
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" item quantity --api-key $K --login-token $T
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" item quantity2 --codes K001,K002 --api-key $K --login-token $T
# موجودی اول دوره (فایل: [{"code":"K001","quantity":50,"unitPrice":800000}])
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" item opening-quantity --file /tmp/opening.json --api-key $K --login-token $T
# رسید ورود کالا (خرید بدون فاکتور)
python3 "${HERMES_SKILL_DIR}/scripts/hesabfa.py" warehouse save --warehouse-code 1 --receiving --invoice-type خرید --items-json '[{"itemCode":"K001","quantity":10}]' --api-key $K --login-token $T
```

---

## نکات فرا-گردشی

- **قبل از هر ثبت:** با `--dry-run` بدنه را چک کن؛ برای اشیای بزرگ فایل JSON بساز (`--file`) نه رشته inline.
- **تحقق بعد از ثبت:** هر save را با get/list همان ماژول تأیید کن؛ exit code صفر یعنی `Success: true`.
- **جستجو:** سرور کلید `search` را در عمل نادیده می‌گیرد؛ CLI خودش `--search` را به فلتر شامل روی فیلد نام ماژول ترجمه می‌کند و برای فیلدهای دیگر باید از `--filter 'فیلد:*:متن'` استفاده کنی. چند فلتر AND می‌شوند.
- **نوع شخص:** سرور `contactType` را نادیده می‌گیرد و از `company` نتیجه می‌گیرد — شخص حقوقی ⇒ حتماً `--company`.
- **تاریخ «امروز»:** به وقت تهران حل می‌شود (نه ساعت ماشین اجرا).
- **حذف‌ها برگشت‌ناپذیر نیستند** — قبل از `delete` از کاربر تأیید بگیر.
- **پارامتر سال مالی:** اگر کاربر گفت «سال مالی 1402»، سال‌های مالی را با `setting fiscal-years` بگیر و `--year-id` مناسب را بده (سال اول = 1).
- **واحد پول:** پیش‌فرض از `setting currency` خوانده می‌شود (معمولاً IRR/Rial)؛ مبالغ را با کاربر شفاف کن (ریال یا تومان).
- **صفحه‌بندی:** برای شمارش کامل رکوردها از `TotalCount` استفاده کن و با skip ادامه بده؛ `--result` فقط Result را چاپ می‌کند و برای خواندن توسط برنامه مناسب‌تر است.
- **ساختار سطر تراز آزمایشی:** هر سطر `Account{Path, Name, AccountType, MainAccountType}` دارد (نه AccountPath) + `Debit, Credit, Balance, BalanceType, OpeningDebit, OpeningCredit, RemainingDebit, RemainingCredit` — به رکوردهای گروهی با Account خالی دقت کن.
