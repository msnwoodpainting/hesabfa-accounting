# ساختار اشیای JSON حسابفا

> این فایل ساختار کامل اشیای درخواست/پاسخ را مستند می‌کند. وقتی قرار است با `--file` یا `--json` شیء کامل بسازی، ساختار فیلدها را از اینجا بردار. جداول enum (انواع فاکتور، نوع رسید و...) در `references/enums-errors.md` است.

نکته نام‌گذاری: فیلدهای **درخواست** (save) با حروف کوچک شروع می‌شوند (lowerCamelCase) ولی فیلدهای **پاسخ** با حروف بزرگ (PascalCase). فیلترهای `queryInfo` باید از نام‌گذاری پاسخ استفاده کنند (`Name` نه `name`).

## ۱. شخص (Contact)

پاسخ: `Id, Code, Name, Company, FirstName, LastName, ContactType, NationalCode, EconomicCode, RegistrationNumber, Title, Address, Country, City, State, PostalCode, Phone, Fax, Mobile, Email, Website, BirthDate, WeddingDate, MembershipDate, BranchCode, Note, IsShareHolder, IsCustomer, IsVendor, IsEmployee, SharePercent, Liability, Credits, ContactCredit, Tag, Active, TaxType, NodeId, NodeName, NodeFamily`

درخواست `contact/save` (شیء `contact`):
```json
{
  "code": "0001",
  "name": "شرکت توحید",
  "contactType": 2,
  "firstName": "محمد",
  "lastName": "محمدی",
  "company": "شرکت توحید",
  "nationalCode": "65465465465",
  "economicCode": "13232323221",
  "registrationNumber": "9879898798798",
  "title": "شرکت توحید",
  "address": "تهران، خیابان ولیعصر",
  "city": "تهران",
  "state": "تهران",
  "postalCode": "2154665656",
  "phone": "02188664523",
  "fax": "02188664524",
  "mobile": "09361234567",
  "email": "info@sample.com",
  "website": "",
  "birthDate": "2000-05-04",
  "weddingDate": "2021-05-14",
  "membershipDate": "2023-01-14",
  "note": "",
  "isShareHolder": true,
  "isCustomer": true,
  "isVendor": true,
  "isEmployee": false,
  "contactCredit": 0,
  "tag": "",
  "taxType": 5,
  "active": true,
  "nodeFamily": "اشخاص:اشخاص حقوقی:سازمان ها"
}
```

الزامی: `name` و `contactType` (۰ نامشخص / ۱ حقیقی / ۲ حقوقی). `nodeFamily` مسیر دسته‌بندی با جداکننده «:» است و باید با ریشه «اشخاص» شروع شود.

## ۲. کالا/خدمت (Item)

پاسخ: `Id, Code, Name, ItemType, Unit, SubUnit, ConversionFactor, Barcode, Stock, BuyPrice, SellPrice, PurchasesTitle, SalesTitle, NodeId, NodeName, NodeFamily, Tag, Description, ProductCode, LastPurchaseCost, Active, SalesTaxable, PurchaseTaxable, TaxType, TaxId, TaxUnit, ReorderPoint, LeadTime, MinimumOrder, PriceList[{Title, Currency, Price}], Currency, Price`

درخواست `item/save` (شیء `item`):
```json
{
  "code": "K001",
  "name": "کابل شبکه Cat6",
  "itemType": 0,
  "barcode": "626000000001",
  "unit": "عدد",
  "subUnit": "بسته",
  "conversionFactor": 10,
  "buyPrice": 800000,
  "sellPrice": 950000,
  "purchasesTitle": "کابل Cat6 (خرید)",
  "salesTitle": "کابل شبکه Cat6",
  "description": "کابل شبکه مسی",
  "tag": "شبکه",
  "productCode": "PC-100",
  "active": true,
  "salesTaxable": true,
  "purchaseTaxable": false,
  "taxType": 12,
  "reorderPoint": 10,
  "leadTime": 3,
  "minimumOrder": 5,
  "nodeFamily": "کالاها:لوازم شبکه",
  "priceList": [{"Title": "عمده", "Currency": "IRR", "Price": 900000}]
}
```

الزامی: `name` و `itemType` (۰ کالا / ۱ خدمت). برای خدمت `nodeFamily` باید با «خدمات» شروع شود. `taxType` کالا ۱ تا ۱۲ (جدول enums).

موجودی (`item/GetQuantity`): `Code, Tag, Quantity, Barcode, ProductCode, SellPrice, LastVendor{Id, Code, DisplayName}, LastPurchaseCost, LastPurchaseDate` — `GetQuantity2` علاوه بر آن `Warehouse[]` با `{Code, Quantity}` به تفکیک انبار می‌دهد.

## ۳. فاکتور (Invoice)

پاسخ: `Id, Number, Reference, Date, DueDate, ContactCode, Contact{Code, Name}, ContactTitle, Sum, Payable, Paid, Rest, Note, Sent, Returned, InvoiceType, Status, Tag, Freight, FreightPersonCode, FreightPersonName, WarehouseReceiptStatus, Project, SalesmanCode, SalesmanPercent, Others[{Title, Amount, Add}], Currency, CurrencyRate, TaxId, Profit, InvoiceItems[]`

هر سطر `InvoiceItems`: `Id, RowNumber, ItemCode, Item{...}, Description, Unit, Quantity, UnitPrice, Sum, Discount, Tax, TotalAmount, SerialNumbers[]`

درخواست `invoice/save` (شیء `invoice`) — مثال فاکتور فروش کامل:
```json
{
  "number": "",
  "reference": "SO-1042",
  "date": "2025-11-14",
  "dueDate": "2025-12-14",
  "contactCode": "0001",
  "note": "فاکتور فروش آزمایشی",
  "invoiceType": 0,
  "status": 1,
  "tag": "",
  "freight": 0,
  "freightPersonCode": "",
  "project": "",
  "salesmanCode": "",
  "salesmanPercent": 0,
  "invoiceItems": [
    {
      "rowNumber": 1,
      "itemCode": "K001",
      "description": "کابل شبکه Cat6",
      "unit": "عدد",
      "quantity": 2,
      "unitPrice": 950000,
      "discount": 100000,
      "tax": 90000,
      "serialNumbers": []
    }
  ],
  "others": [
    {"title": "هزینه حمل", "amount": 50000, "add": true}
  ],
  "currency": "",
  "currencyRate": 0
}
```

الزامی: `date`, `dueDate`, `contactCode`, `invoiceType`, و در هر سطر `itemCode`, `description`, `quantity`, `unitPrice`, `discount`, `tax`.

روابط مبالغ (از نمونه رسمی استنتاج شده): `Sum = مجموع (Quantity×UnitPrice)`؛ `TotalAmount = Sum − Discount + Tax`؛ `Payable = مجموع TotalAmount + Others(فقط add=true)`.

## ۴. رسید دریافت/پرداخت (Receipt)

پاسخ: `Id, Number, DateTime, Description, Amount, Currency, CurrencyRate, Project, Items[], Transactions[], Invoice{Id, Number, DateTime, InvoiceType}`
- `Items[]` (طرف حساب): `{Contact{Id, Code, Name}, Account (مسیر حساب), Amount, Description}`
- `Transactions[]` (منبع وجه): `{Bank{...} | Cash | PettyCash | Contact | Check | Account, Type (۱-۷), Reference, TransactionFee, Amount}`

**`receipt/save` (ساده)** — بدنه تخت:
```json
{
  "type": 1,
  "number": "",
  "dateTime": "2025-11-14 10:30:00",
  "project": "",
  "description": "واریز وجه توسط مشتری",
  "bankCode": "1",
  "contactCode": "0001",
  "amount": 5000000,
  "bankFee": 0,
  "reference": "TRX-889",
  "currency": "",
  "currencyRate": 0
}
```

**`receipt/save2` (پیشرفته)** — چند قلم + چند تراکنش + چک:
```json
{
  "type": 1,
  "number": "",
  "dateTime": "2025-11-14 10:30:00",
  "project": "",
  "description": "دریافت چک از مشتری",
  "items": [
    {"contactCode": "0001", "amount": 5000000, "description": "واریز بابت فاکتور 101"}
  ],
  "transactions": [
    {"amount": 3000000, "bankCode": "1", "reference": "TRX-890"},
    {
      "amount": 2000000,
      "check": {
        "number": "5470098",
        "date": "2025-11-20",
        "amount": 2000000,
        "sayyad": "872000545448792",
        "bankName": "تجارت",
        "payerCode": 2
      }
    }
  ]
}
```

فیلدهای چک (`check`):
- چک دریافتی (در رسید دریافت/درآمد/دریافت سایر): `number` (شماره چک), `date`, `amount`, `sayyad` (شماره رهگیری صیاد — طبق مستندات رسمی ۲۴ رقمی، ولی هر مقداری که کاربر می‌دهد را بدون اعتبارسنجی طول منتقل کن؛ سرور ممکن است چک کند), `bankName` (نام بانک صادرکننده), `bankBranch`, `payerCode` (کد شخص مرتبط با چک در حسابفا — همان کد تماسِ پرداخت‌کننده)
- چک پرداختی (در رسید پرداخت/هزینه/پرداخت سایر): `number`, `date`, `amount`, `sayyad`, `payee` (در وجه), `bankCode` (کد بانک صادرکننده از بین بانک‌های ثبت‌شده)
- **خرج چک** (`spendCheck`): چک دریافتی را به‌جای وصول، خرج کن: `{"spendCheck": {"number": "...", "date": "...", "amount": 2000000}}`

پاسخ چک: `Check{Number, Date, Sayyad, Amount, Status, BankCode, BankName, BankBranch, PayerCode, PayerName, Payee}` — مقدار `Status` در مستندات رسمی فهرست نشده (نمونه‌ها ۰ نشان می‌دهند)؛ مقدار خام را به کاربر گزارش کن.

## ۵. رسید/حواله انبار (Warehouse)

پاسخ: `Id, Number, InvoiceNumber, InvoiceType, WarehouseCode, DestinationWarehouseCode, Date, Notes, Delivery, Freight, Project, Receiving (true=رسید ورود / false=حواله خروج), Items[{Id, ItemCode, Reference, Notes, Item{Code, Name}, Quantity}]`

درخواست `warehouse/save`:
```json
{
  "deleteOldReceipts": false,
  "receipt": {
    "number": "",
    "invoiceNumber": "101",
    "invoiceType": 0,
    "warehouseCode": "1",
    "destinationWarehouseCode": "",
    "date": "2025-11-14",
    "notes": "خروج بابت فاکتور فروش",
    "delivery": "",
    "freight": 0,
    "project": "",
    "receiving": false,
    "items": [
      {"itemCode": "K001", "quantity": 2, "reference": "", "notes": ""}
    ]
  }
}
```

## ۶. سند حسابداری (Document)

پاسخ: `Id, Number, Reference, Date, Description, Project, Debit, Credit, Status, Transactions[]`

هر سطر سند: `Id, AccountPath, Description, Info, Amount, CurrencyAmount, Currency, Type (0 بدهکار / 1 بستانکار), ContactCode, ProductCode, BankCode, CashCode, PettyCashCode`

درخواست `document/save`:
```json
{
  "document": {
    "number": "",
    "reference": "",
    "date": "2025-11-14",
    "description": "دریافت پیش‌پرداخت از مشتری",
    "project": "",
    "status": 1,
    "transactions": [
      {
        "accountPath": "دارایی ها:دارایی های جاری:صندوق",
        "description": "ورود نقد به صندوق",
        "amount": 1000000,
        "type": 0,
        "cashCode": "1"
      },
      {
        "accountPath": "بدهی ها:بدهی های جاری:پیش دریافت فروش",
        "description": "پیش دریافت از مشتری",
        "amount": 1000000,
        "type": 1,
        "contactCode": "0001"
      }
    ]
  }
}
```

`accountPath` دقیقاً از جدول حساب‌ها (`setting/getAccounts` → فیلد `FullPath`) برداشته شود. سند باید تراز باشد.

## ۷. تخفیف (DisCountItem) و انتقال بانکی (BankTransfer)

تخفیف — پاسخ: `Id, Title, Type (1-6), ContactCode, ProductCode, ContactPath, ProductPath, ValidFrom, ValidTo, Percent, Amount, OneTime, UseCount, UseDate, Info, Tag`
درخواست `disCountItem/save`: `{"item": {"id": 0, "title": "تخفیف نوروز", "type": 3, "percent": 10, "amount": 0, "validFrom": "2025-03-21", "validTo": "2025-04-02", "tag": ""}}`

انتقال بانکی — درخواست `bankTransfer/save`:
```json
{
  "transfer": {
    "number": "",
    "description": "انتقال از بانک به صندوق",
    "project": "",
    "date": "2025-11-14",
    "fromAmount": 2000000,
    "fromReference": "TRX-1",
    "fromBank": "1",
    "fromTransactionFee": 0,
    "fromCurrencyRate": 0,
    "toAmount": 2000000,
    "toReference": "",
    "toCash": "1",
    "toTransactionFee": 0,
    "toCurrencyRate": 0
  }
}
```

## ۸. ساختار پاسخ گزارش‌ها

- **balanceSheet:** درخت حساب‌ها `{Account, Name, MainAccountType, DetailType, Debit, Credit, TotalDebit, TotalCredit, Balance, TotalBalance, Children[]}` + جمع‌های `Assets, Liabilities, Equity, ProfitOrLoss`
- **profitandlossStatement:** همان درخت + `InventoryAdjustment, BeginningInventory, EndingInventory, ProfitOrLoss, IncomeTax, ProfitOrLossAfterTax`
- **trialBalance:** سطرهای `{Account{Path, Name, AccountType, MainAccountType}, Debit, Credit, Balance, BalanceType, OpeningDebit, OpeningCredit, RemainingDebit, RemainingCredit}` — رکوردهای گروهی (جمع سرگروه‌ها) `Account` خالی دارند (اصلاح با تست زنده ۱۴۰۵/۰۸/۲۴)
- **trialBalanceItems:** `{Code, Name, Debit, Credit, Balance, BalanceType}` (تفصیل: شخص/بانک/صندوق/تنخواه/کالا)
- **debtorsCreditors:** `{Code, Name, NodeName, NodeFamily, Debit, Credit, LastReceiveDate, LastPayDate}`
- **inventory:** `{Code, Name, NodeName, NodeFamily, MainUnit, SubUnit, ProductCode, Amount, Quantity, Opening, Increase, Decrease}`
- **bank/cash/pettyCash:** `{DateTime, DocumentNumber, Description, Amount, Type, Debit, Credit, Reference}`
- **journal:** صفحه‌بندی‌شده `{TotalCount, FilteredCount, From, To, List[]}` با سطرهای `{DateTime, AccountPath, Detail, DocumentNumber, Description, Type, Debit, Credit}` — در عمل ممکن است `FilteredCount` صفر باشد حتی وقتی `List` پر است (تست زنده)؛ به `List` تکیه کن

## ۹. پاسخ استعلام‌ها (Inquiry)

همه: `Result = {Status, Message, Data{...}}`
- nationalIdentity → `Data: {Matched, FirstName, LastName, NationalCode, IsDead, Alive}`
- تطابق‌ها (mobile/card/iban + nationalCode) → `Data: {Matched}`
- iban → `Data: {Name, BankName, IsTransferable}`
- card → `Data: {Name}`
- cardToIban → `Data: {IBAN, BankName, Name}`
- accountToIBAN → `Data: {IBAN}`
- postalCode → `Data: {Address{Province, Town, District, Street, Street2, Number, Floor, SideFloor, BuildingName, Description}}`
- credit → `Result` عدد توکن باقیمانده
