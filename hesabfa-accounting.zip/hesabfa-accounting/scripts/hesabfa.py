#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hesabfa.py — رابط خط فرمان (CLI) برای API نرم‌افزار حسابداری آنلاین حسابفا
=============================================================================
پوشش کامل ۹۲ متد رسمی API حسابفا در ۱۲ ماژول، فقط با کتابخانه استاندارد پایتون.

نمونه استفاده:
    python3 hesabfa.py --api-key KEY --login-token TOKEN setting getFiscalYears
    python3 hesabfa.py --api-key KEY --login-token TOKEN contact list --search "شرکت"
    python3 hesabfa.py --api-key KEY --login-token TOKEN invoice save --file invoice.json
    python3 hesabfa.py call setting/getChanges --data '{"start": 100}' --api-key KEY --login-token TOKEN

اعتبارنامه (به یکی از دو روش):
    * پرچم‌ها: --api-key و (--login-token یا --user-id + --password)
    * متغیر محیطی: HESABFA_API_KEY و (HESABFA_LOGIN_TOKEN یا HESABFA_USER_ID + HESABFA_PASSWORD)

کدهای خروج (exit codes):
    0 = موفق (Success=true)   2 = خطای شبکه/HTTP   3 = خطای منطقی API (Success=false)   4 = خطای استفاده/پارامتر
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import date, datetime, timedelta

BASE_URL_DEFAULT = "https://api.hesabfa.com/v1"

# ---------------------------------------------------------------------------
# ابزارهای تاریخ: پذیرش تاریخ شمسی (مثل 1404/08/23) و میلادی (2025-11-14)
# ---------------------------------------------------------------------------

def jalali_to_gregorian(jy, jm, jd):
    """تبدیل تاریخ هجری شمسی به میلادی (الگوریتم استاندارد)."""
    jy += 1595
    days = (-355668 + (365 * jy) + ((jy // 33) * 8) + (((jy % 33) + 3) // 4)
            + jd + ((jm - 1) * 31 if jm < 7 else ((jm - 7) * 30) + 186))
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        days -= 1
        gy += 100 * (days // 36524)
        days %= 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        days -= 1
        gy += days // 365
        days %= 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or (gy % 400 == 0)
    md = [0, 31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 1
    for i in range(1, 13):
        if gd > md[i]:
            gd -= md[i]
        else:
            gm = i
            break
    return gy, gm, gd


def tehran_today():
    """تاریخ امروز به وقت تهران (یافته تست زنده ۱۴۰۵/۰۸/۲۴: clock سرور سنگ‌بستر
    بر UTC است و «امروز» نباید به وقت ماشین اجرا حل شود — کاربر اسکیل ایرانی است)."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Asia/Tehran")).date()
    except Exception:
        # ایران از ۱۴۰۱ ساعت تابستانی ندارد؛ آفست ثابت +۳:۳۰
        return (datetime.utcnow() + timedelta(hours=3, minutes=30)).date()


def normalize_date(value):
    """ورودی: 1404/08/23 | 1404-08-23 | 2025-11-14 | today | همراه با ساعت.
    خروجی: رشته میلادی ISO مناسب حسابفا."""
    v = str(value).strip().lower()
    if v in ("today", "امروز"):
        return tehran_today().isoformat()
    time_part = ""
    head = v
    if " " in v:
        head, time_part = v.split(" ", 1)
        time_part = " " + time_part
    sep = "/" if "/" in head else "-"
    parts = head.split(sep)
    if len(parts) != 3:
        raise SystemExit("خطا (کد 4): فرمت تاریخ نامعتبر است: «%s» — از 1404/08/23 یا 2025-11-14 استفاده کنید" % value)
    try:
        y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError:
        raise SystemExit("خطا (کد 4): تاریخ عددی نیست: «%s»" % value)
    if y <= 1500:  # شمسی
        y, m, d = jalali_to_gregorian(y, m, d)
    return "%04d-%02d-%02d%s" % (y, m, d, time_part)


# ---------------------------------------------------------------------------
# جدول‌های enum: پذیرش عدد یا نام فارسی/انگلیسی
# ---------------------------------------------------------------------------
INVOICE_TYPES = {"0": 0, "sale": 0, "فروش": 0,
                 "1": 1, "purchase": 1, "خرید": 1,
                 "2": 2, "sales-return": 2, "برگشت از فروش": 2,
                 "3": 3, "purchase-return": 3, "برگشت از خرید": 3,
                 "4": 4, "scrap": 4, "ضایعات": 4}
RECEIPT_TYPES = {"1": 1, "receive": 1, "دریافت": 1,
                 "2": 2, "pay": 2, "پرداخت": 2,
                 "3": 3, "income": 3, "درآمد": 3,
                 "4": 4, "expense": 4, "هزینه": 4,
                 "5": 5, "other-receive": 5, "دریافت سایر": 5,
                 "6": 6, "other-pay": 6, "پرداخت سایر": 6}
ITEM_TYPES = {"0": 0, "goods": 0, "کالا": 0, "1": 1, "service": 1, "خدمت": 1, "خدمات": 1}
CONTACT_TYPES = {"0": 0, "unknown": 0, "نامشخص": 0,
                 "1": 1, "real": 1, "حقیقی": 1,
                 "2": 2, "legal": 2, "حقوقی": 2}
WAREHOUSE_TYPES = {"1": 1, "in": 1, "ورود": 1, "رسید": 1,
                   "2": 2, "out": 2, "خروج": 2, "حواله": 2}
STATUS_TYPES = {"0": 0, "draft": 0, "پیش‌نویس": 0, "پیش نویس": 0,
                "1": 1, "confirmed": 1, "تأییدشده": 1, "تایید شده": 1}


def resolve_enum(value, table, what):
    if value is None:
        return None
    key = str(value).strip()
    low = key.lower()
    if low in table:
        return table[low]
    if key in table:
        return table[key]
    raise SystemExit("خطا (کد 4): مقدار %s نامعتبر است: «%s»" % (what, value))


# ---------------------------------------------------------------------------
# خطای استفاده
# ---------------------------------------------------------------------------
def usage_error(msg):
    raise SystemExit("خطا (کد 4): " + msg)


# ---------------------------------------------------------------------------
# کلاینت API
# ---------------------------------------------------------------------------
MUTATION_HINTS = ("save", "delete", "set", "change")


def is_mutation(path):
    low = path.lower()
    if "getchanges" in low:
        return False
    return any(h in low for h in MUTATION_HINTS)


def read_json_arg(opts, raw, what="JSON"):
    """پذیرش JSON مستقیم، @مسیر-فایل، یا - (stdin)."""
    if raw is None:
        return None
    raw = raw.strip()
    if raw.startswith("@"):
        path = raw[1:]
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            usage_error("فایل «%s» پیدا نشد" % path)
        except json.JSONDecodeError as exc:
            usage_error("فایل «%s» JSON معتبر نیست: %s" % (path, exc))
    if raw == "-":
        try:
            return json.load(sys.stdin)
        except json.JSONDecodeError as exc:
            usage_error("JSON ورودی stdin معتبر نیست: %s" % exc)
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        usage_error("%s معتبر نیست: %s\n%s" % (what, exc, raw[:200]))


def build_queryinfo(args, name_field=None):
    """ساخت شیء queryInfo از آرگومان‌های استاندارد لیست.

    یافته تست زنده (۱۴۰۵/۰۸/۲۴): سرور حسابفا کلیدهای «search» و «searchFields»
    را در queryInfo نادیده می‌گیرد (هم در contact/getContacts و هم item/getItems)
    و چند فلتر نیز با هم AND می‌شوند. بنابراین --search به یک فلتر «شامل»
    (عملگر *) تبدیل می‌شود: روی تک‌فیلدِ --search-fields اگر فقط یکی باشد،
    وگرنه روی فیلد نامِ ماژول (name_field). در غیر این صورت search خام
    فرستاده می‌شود و هشدار داده می‌شود.
    """
    qi = {"take": getattr(args, "take", None) or 20, "skip": getattr(args, "skip", None) or 0}
    if getattr(args, "sort_by", None):
        qi["sortBy"] = args.sort_by
    if getattr(args, "sort_desc", None):
        qi["sortDesc"] = True

    fields = []
    if getattr(args, "search_fields", None):
        fields = [f.strip() for f in args.search_fields.split(",") if f.strip()]

    search_filter = None
    search = getattr(args, "search", None)
    if search:
        if len(fields) == 1 or (not fields and name_field):
            search_filter = {"property": fields[0] if fields else name_field,
                             "operator": "*", "value": search}
        else:
            qi["search"] = search
            if fields:
                qi["searchFields"] = fields
            sys.stderr.write("هشدار: سرور حسابفا کلید search را در عمل نادیده می‌گیرد (تست زنده ۱۴۰۵/۰۸/۲۴)؛ "
                             "برای جستجوی قطعی از --filter 'فیلد:*:متن' استفاده کنید.\n")

    raw_filters = getattr(args, "filter", None)
    if raw_filters:
        operators = (">=", "<=", "!=", "?*", "*?", "=", ">", "<", "in", "*")
        filters = []
        for spec in raw_filters:
            parts = spec.split(":", 2)
            if len(parts) == 3:
                prop, op, val = parts[0].strip(), parts[1].strip(), parts[2].strip()
            elif len(parts) == 2:
                # فرمت کوتاه مثل 'ContactCredit:>100000' یا 'Name*شرکت'
                prop, rest = parts[0].strip(), parts[1].strip()
                op, val = None, rest
                for cand in operators:
                    if rest.startswith(cand):
                        op, val = cand, rest[len(cand):].strip()
                        break
                if op is None:
                    usage_error("عملگر در فیلتر «%s» پیدا نشد — مثال: 'Name:*:شرکت' یا 'ContactCredit:>100000'" % spec)
            else:
                usage_error("فیلتر باید به شکل property:operator:value باشد: «%s»" % spec)
            if op not in operators:
                usage_error("عملگر فیلتر نامعتبر: «%s» — مجاز: = != > >= < * ?* *? in" % op)
            try:
                parsed = json.loads(val)
            except json.JSONDecodeError:
                parsed = val
            filters.append({"property": prop, "operator": op, "value": parsed})
        qi["filters"] = filters
    if search_filter:
        qi.setdefault("filters", []).append(search_filter)
    return qi


def num(value):
    """تبدیل عدد: اگر صحیح بود int برگردان نه float."""
    if value is None:
        return None
    try:
        f = float(value)
        return int(f) if f.is_integer() else f
    except (TypeError, ValueError):
        return value


def mask_creds(body):
    """ماسک کردن اعتبارنامه در خروجی dry-run (سیاست امنیتی اسکیل)."""
    masked = dict(body)
    for key in ("apiKey", "loginToken", "password"):
        if key in masked and isinstance(masked[key], str) and masked[key]:
            masked[key] = masked[key][:4] + "…" if key != "password" else "****"
    return masked


def api_call(method_path, payload, opts):
    """ارسال درخواست POST به api.hesabfa.com و بازگرداندن پاکت پاسخ."""
    if not opts.api_key:
        usage_error("apiKey تنظیم نشده — از کاربر بخواهید کلید را بدهد "
                    "(پرچم --api-key یا متغیر محیطی HESABFA_API_KEY). کلید در حسابفا: تنظیمات > تنظیمات مالی > API")
    if not opts.login_token and not (opts.user_id and opts.password):
        usage_error("اعتبارنامه ناقص — loginToken لازم است (--login-token یا HESABFA_LOGIN_TOKEN) "
                    "یا userId و password را بدهید. توکن در حسابفا: تنظیمات > تنظیمات مالی > API")

    body = dict(payload) if payload else {}
    body["apiKey"] = opts.api_key
    if opts.login_token:
        body["loginToken"] = opts.login_token
    else:
        body["userId"] = opts.user_id
        body["password"] = opts.password
    if opts.year_id:
        body["yearId"] = opts.year_id
    if opts.idempotency and is_mutation(method_path):
        body["requestUniqueId"] = str(uuid.uuid4())

    url = opts.base_url.rstrip("/") + "/" + method_path.strip("/")
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")

    if opts.dry_run:
        print(json.dumps({"dry_run": True, "url": url, "method": "POST",
                          "body": mask_creds(body)}, ensure_ascii=False,
                         indent=None if opts.compact else 2))
        sys.exit(0)

    attempts = 0
    while True:
        attempts += 1
        req = urllib.request.Request(
            url, data=data, method="POST",
            headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=opts.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                try:
                    envelope = json.loads(raw)
                except json.JSONDecodeError:
                    sys.stderr.write("خطا (کد 2): پاسخ HTTP 200 اما JSON معتبر نیست\n")
                    sys.exit(2)
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:300]
            except Exception:
                pass
            sys.stderr.write("خطا (کد 2): HTTP %s برای %s%s\n" % (exc.code, url, (" — " + detail) if detail else ""))
            sys.exit(2)
        except urllib.error.URLError as exc:
            sys.stderr.write("خطا (کد 2): خطای شبکه برای %s — %s\n" % (url, exc.reason))
            sys.exit(2)

        if not isinstance(envelope, dict) or "Success" not in envelope:
            sys.stderr.write("خطا (کد 2): ساختار پاسخ غیرمنتظره از حسابفا\n")
            sys.exit(2)

        # محدودیت نرخ: خطای 101 → حداقل ۱۰ ثانیه صبر و یک بار تلاش مجدد
        if envelope.get("Success") is False and envelope.get("ErrorCode") == 101 and opts.retry_rate_limit and attempts == 1:
            sys.stderr.write("محدودیت نرخ (خطای 101): ۱۰ ثانیه صبر می‌کنم و یک بار دیگر تلاش می‌کنم...\n")
            time.sleep(10)
            continue
        return envelope


def print_envelope(envelope, opts):
    if opts.result:
        out = envelope.get("Result")
    else:
        out = envelope
    text = json.dumps(out, ensure_ascii=False, indent=None if opts.compact else 2)
    print(text)


def finish(envelope, opts):
    print_envelope(envelope, opts)
    if envelope.get("Success") is False:
        sys.stderr.write("خطای API %s: %s\n" % (envelope.get("ErrorCode"), envelope.get("ErrorMessage")))
        sys.exit(3)
    sys.exit(0)


# ---------------------------------------------------------------------------
# پارامترهای اشتراکی argparse
# ---------------------------------------------------------------------------
def register_common(p):
    p.add_argument("--api-key", help="کلید API حسابفا (یا HESABFA_API_KEY)")
    p.add_argument("--login-token", help="توکن ورود کسب‌وکار (یا HESABFA_LOGIN_TOKEN)")
    p.add_argument("--user-id", help="ایمیل/موبایل مالک کسب‌وکار (یا HESABFA_USER_ID)")
    p.add_argument("--password", help="رمز مالک (یا HESABFA_PASSWORD)")
    p.add_argument("--year-id", type=int, help="شناسه سال مالی (پیش‌فرض: آخرین سال)")
    p.add_argument("--base-url", default=BASE_URL_DEFAULT, help="آدرس پایه API")
    p.add_argument("--timeout", type=int, default=30, help="زمان انتظار شبکه به ثانیه")
    p.add_argument("--dry-run", action="store_true", help="فقط نمایش بدنه درخواست بدون ارسال")
    p.add_argument("--compact", action="store_true", help="خروجی JSON فشرده (تک‌خطی)")
    p.add_argument("--result", action="store_true", help="فقط چاپ Result به‌جای کل پاکت")
    p.add_argument("--idempotency", action="store_true",
                   help="ارسال requestUniqueId برای متدهای ثبت/حذف (جلوگیری از ثبت تکراری)")
    p.add_argument("--no-retry-rate-limit", dest="retry_rate_limit", action="store_false", default=True,
                   help="در خطای 101 تلاش مجدد نکن")
    return p


COMMON = register_common(argparse.ArgumentParser(add_help=False))


# پرچم‌های عمومی که از هر موقعیتی در خط فرمان استخراج می‌شوند
# (زیرا argparse مقادیر قبل از زیرفرمان را با پیش‌فرض زیرفرمان بازنویسی می‌کند)
GLOBAL_VALUED = ("--api-key", "--login-token", "--user-id", "--password",
                 "--year-id", "--base-url", "--timeout")
GLOBAL_BOOLS = ("--dry-run", "--compact", "--result", "--idempotency", "--no-retry-rate-limit")


def extract_globals(argv):
    """استخراج پرچم‌های عمومی از هر موقعیت و حذف آن‌ها از argv."""
    extracted, out = {}, []
    i = 0
    while i < len(argv):
        tok = argv[i]
        consumed = False
        for f in GLOBAL_VALUED:
            if tok == f and i + 1 < len(argv):
                extracted[f] = argv[i + 1]
                i += 2
                consumed = True
                break
            if tok.startswith(f + "="):
                extracted[f] = tok.split("=", 1)[1]
                i += 1
                consumed = True
                break
        if consumed:
            continue
        if tok in GLOBAL_BOOLS:
            extracted[tok] = True
            i += 1
            continue
        out.append(tok)
        i += 1
    return extracted, out


def leaf(container, name, **kwargs):
    """ساخت فرمان برگ با پارامترهای عمومی — تا پرچم‌ها در هر موقعیت کار کنند."""
    return container.add_parser(name, parents=[COMMON], **kwargs)


def add_queryinfo(p):
    p.add_argument("--take", type=int, help="حداکثر رکورد (پیش‌فرض CLI: 20 — سرور بدون آن 10 برمی‌گرداند)")
    p.add_argument("--skip", type=int, help="تعداد رکورد پرش از ابتدا")
    p.add_argument("--sort-by", help="مرتب‌سازی بر اساس فیلد (با همان حروف پاسخ، مثل Name)")
    p.add_argument("--sort-desc", action="store_true", help="مرتب‌سازی نزولی")
    p.add_argument("--search", help="جستجوی متنی — به فلتر شامل (*) روی فیلد نام ترجمه می‌شود؛ سرور کلید search را نادیده می‌گیرد (تست زنده)")
    p.add_argument("--search-fields", help="فیلدهای جستجو جدا با کاما (مثل Name,Mobile)")
    p.add_argument("--filter", action="append", metavar="property:operator:value",
                   help="فیلتر (قابل تکرار). عملگرها: = != > >= < * ?* *? in — مثال: 'Name:*:شرکت'")


def add_dates(p):
    p.add_argument("--start-date", help="تاریخ شروع (شمسی 1404/01/01 یا میلادی 2025-03-21)")
    p.add_argument("--end-date", help="تاریخ پایان")


def resolve_date_kwargs(args, payload):
    for src, dst in (("start_date", "startDate"), ("end_date", "endDate"),
                     ("date", "date"), ("due_date", "dueDate"), ("date_time", "dateTime")):
        val = getattr(args, src, None)
        if val:
            payload[dst] = normalize_date(val)


# ---------------------------------------------------------------------------
# ساخت زیرفرمان‌ها
# ---------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(
        prog="hesabfa.py",
        description="CLI پوشش کامل API حسابفا — حسابداری آنلاین (۱۲ ماژول، ۹۲ متد)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="مستندات کامل هر متد: references/api-reference.md داخل پوشه اسکیل")
    register_common(parser)
    sub = parser.add_subparsers(dest="cmd", required=True)

    # ---------------- contact ----------------
    p = sub.add_parser("contact", help="اشخاص (مشتری/تامین‌کننده/کارمند)")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="دریافت لیست اشخاص (contact/getContacts)")
    add_queryinfo(c1)
    c1.set_defaults(method="contact/getContacts", qinfo=True, name_field="Name")

    c2 = leaf(c, "get", help="دریافت یک شخص با کد (contact/get)")
    c2.add_argument("--code", required=True)
    c2.set_defaults(method="contact/get", fixed={"code": "code"})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه داخلی (contact/getById)")
    c3.add_argument("--ids", required=True, help="شناسه‌ها جدا با کاما")
    c3.set_defaults(method="contact/getById", idlist=True)

    c4 = leaf(c, "save", help="ثبت/ویرایش شخص (contact/save)")
    c4.add_argument("--file", help="فایل JSON کامل شخص (پیشنهادی برای فیلدهای زیاد)")
    c4.add_argument("--json", help="JSON کامل شخص به‌صورت رشته")
    c4.add_argument("--code", help="کد شخص (خالی = کد خودکار)")
    c4.add_argument("--name", help="نام شخص (الزامی)")
    c4.add_argument("--contact-type", help="0 نامشخص / 1 حقیقی / 2 حقوقی (الزامی) — توجه: سرور این فیلد را نادیده می‌گیرد و از company نتیجه می‌گیرد؛ برای حقوقی حتماً --company بدهید")
    c4.add_argument("--first-name"); c4.add_argument("--last-name"); c4.add_argument("--company")
    c4.add_argument("--national-code"); c4.add_argument("--economic-code"); c4.add_argument("--mobile")
    c4.add_argument("--phone"); c4.add_argument("--email"); c4.add_argument("--address")
    c4.add_argument("--city"); c4.add_argument("--state"); c4.add_argument("--postal-code")
    c4.add_argument("--tag"); c4.add_argument("--note"); c4.add_argument("--node-family",
        help="مسیر دسته‌بندی مثل 'اشخاص:اشخاص حقوقی:مشتریان'")
    c4.add_argument("--tax-type", help="نوع مالیاتی 5 تا 8")
    c4.add_argument("--is-customer", action="store_true"); c4.add_argument("--is-vendor", action="store_true")
    c4.add_argument("--is-employee", action="store_true"); c4.add_argument("--is-shareholder", action="store_true")
    c4.set_defaults(save_builder="contact")

    c5 = leaf(c, "batchsave", help="ثبت گروهی اشخاص (contact/batchSave)")
    c5.add_argument("--file", required=True, help="فایل JSON آرایه اشخاص")
    c5.set_defaults(method="contact/batchSave", passthrough="contacts")

    c6 = leaf(c, "delete", help="حذف شخص (contact/delete)")
    c6.add_argument("--code", required=True)
    c6.set_defaults(method="contact/delete", fixed={"code": "code"})

    c7 = leaf(c, "ledgerlink", help="لینک عمومی کارت حساب (contact/getContactLink)")
    c7.add_argument("--code", required=True)
    c7.add_argument("--show-all-accounts", action="store_true")
    c7.add_argument("--days", type=int, default=30, help="اعتبار لینک به روز (پیش‌فرض 30)")
    c7.set_defaults(method="contact/getContactLink", days_flag=True)

    # ---------------- item ----------------
    p = sub.add_parser("item", help="کالاها و خدمات")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست کالا/خدمت (item/getItems)")
    add_queryinfo(c1)
    c1.set_defaults(method="item/getItems", qinfo=True, name_field="Name")

    c2 = leaf(c, "get", help="دریافت کالا با کد (item/get)")
    c2.add_argument("--code", required=True)
    c2.set_defaults(method="item/get", fixed={"code": "code"})

    c2b = leaf(c, "getbybarcode", help="دریافت با بارکد (item/getByBarcode)")
    c2b.add_argument("--barcode", required=True)
    c2b.set_defaults(method="item/getByBarcode", fixed={"barcode": "barcode"})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه (item/getById)")
    c3.add_argument("--ids", required=True)
    c3.set_defaults(method="item/getById", idlist=True)

    c4 = leaf(c, "save", help="ثبت/ویرایش کالا یا خدمت (item/save)")
    c4.add_argument("--file"); c4.add_argument("--json")
    c4.add_argument("--code", help="کد کالا (خالی = خودکار)")
    c4.add_argument("--name", help="نام کالا (الزامی)")
    c4.add_argument("--item-type", help="کالا یا خدمت (الزامی): کالا/خدمت/0/1")
    c4.add_argument("--barcode"); c4.add_argument("--unit"); c4.add_argument("--sub-unit")
    c4.add_argument("--buy-price", type=float); c4.add_argument("--sell-price", type=float)
    c4.add_argument("--node-family", help="مثل 'کالاها:لوازم جانبی'")
    c4.add_argument("--description"); c4.add_argument("--tag")
    c4.add_argument("--sales-taxable", action="store_true"); c4.add_argument("--purchase-taxable", action="store_true")
    c4.add_argument("--tax-type", help="نوع مالیات کالا 1 تا 12")
    c4.set_defaults(save_builder="item")

    c5 = leaf(c, "batchsave", help="ثبت گروهی کالاها (item/batchSave)")
    c5.add_argument("--file", required=True)
    c5.set_defaults(method="item/batchSave", passthrough="items")

    c6 = leaf(c, "delete", help="حذف کالا (item/delete)")
    c6.add_argument("--code", required=True)
    c6.set_defaults(method="item/delete", fixed={"code": "code"})

    c7 = leaf(c, "quantity", help="موجودی کالاها (item/GetQuantity)")
    c7.add_argument("--warehouse-code"); c7.add_argument("--codes", help="کدها جدا با کاما")
    c7.set_defaults(method="item/GetQuantity", csv_fields=["codes"], optmap={"warehouseCode": "warehouse_code"})

    c8 = leaf(c, "quantity2", help="موجودی با تفکیک انبارها (item/GetQuantity2)")
    c8.add_argument("--codes", help="کدها جدا با کاما")
    c8.set_defaults(method="item/GetQuantity2", csv_fields=["codes"])

    c9 = leaf(c, "opening-quantity", help="به‌روزرسانی موجودی اول دوره (item/UpdateOpeningQuantity)")
    c9.add_argument("--file", required=True, help='JSON: [{"code":"..","quantity":10,"unitPrice":1000}, ...]')
    c9.set_defaults(method="item/UpdateOpeningQuantity", passthrough="items")

    # ---------------- invoice ----------------
    p = sub.add_parser("invoice", help="فاکتورها (فروش/خرید/برگشتی/ضایعات)")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست فاکتورها (invoice/getInvoices)")
    c1.add_argument("--type", required=True, help="نوع فاکتور: فروش/خرید/برگشت از فروش/برگشت از خرید/ضایعات یا 0-4")
    add_queryinfo(c1)
    c1.set_defaults(method="invoice/getInvoices", qinfo=True, enum={"target": "type", "table": INVOICE_TYPES})

    c2 = leaf(c, "get", help="دریافت فاکتور (invoice/get)")
    c2.add_argument("--number", required=True); c2.add_argument("--type", required=True)
    c2.set_defaults(method="invoice/get", fixed={"number": "number"}, enum={"target": "type", "table": INVOICE_TYPES})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه (invoice/getById)")
    c3.add_argument("--ids", required=True)
    c3.set_defaults(method="invoice/getById", idlist=True)

    c4 = leaf(c, "save", help="ثبت/ویرایش فاکتور (invoice/save)")
    c4.add_argument("--file", help="فایل JSON کامل فاکتور (پیشنهادی — شامل invoiceItems)")
    c4.add_argument("--json", help="JSON کامل فاکتور به‌صورت رشته")
    c4.add_argument("--number", help="شماره فاکتور (خالی = شماره خودکار)")
    c4.add_argument("--date", help="تاریخ فاکتور (الزامی)"); c4.add_argument("--due-date", help="تاریخ سررسید (الزامی)")
    c4.add_argument("--contact-code", help="کد شخص (الزامی)"); c4.add_argument("--invoice-type", help="نوع (الزامی): فروش/خرید/...")
    c4.add_argument("--status", help="0 پیش‌نویس / 1 تأییدشده")
    c4.add_argument("--project"); c4.add_argument("--note"); c4.add_argument("--tag"); c4.add_argument("--reference")
    c4.add_argument("--salesman-code"); c4.add_argument("--salesman-percent", type=float)
    c4.add_argument("--currency"); c4.add_argument("--currency-rate", type=float)
    c4.add_argument("--items-json", help='JSON اقلام: [{"itemCode":"..","quantity":2,"unitPrice":50000,"discount":0,"tax":9000,"description":".."}]')
    c4.add_argument("--others-json", help='JSON سایر مبالغ: [{"title":"حمل","amount":100000,"add":true}]')
    c4.set_defaults(save_builder="invoice")

    c6 = leaf(c, "delete", help="حذف فاکتور (invoice/delete)")
    c6.add_argument("--number", required=True); c6.add_argument("--type", required=True)
    c6.set_defaults(method="invoice/delete", fixed={"number": "number"}, enum={"target": "type", "table": INVOICE_TYPES})

    c7 = leaf(c, "save-payment", help="ثبت دریافت/پرداخت فاکتور (invoice/savePayment)")
    c7.add_argument("--number", required=True); c7.add_argument("--type", required=True)
    c7.add_argument("--amount", required=True, type=float)
    c7.add_argument("--transaction-number", required=True, help="شماره تراکنش/پیگیری (الزامی)")
    src = c7.add_mutually_exclusive_group(required=True)
    src.add_argument("--bank-code"); src.add_argument("--cash-code"); src.add_argument("--petty-cash-code")
    c7.add_argument("--date", help="تاریخ (پیش‌فرض امروز)"); c7.add_argument("--contact-code")
    c7.add_argument("--description"); c7.add_argument("--project"); c7.add_argument("--transaction-fee", type=float)
    c7.add_argument("--currency"); c7.add_argument("--currency-rate", type=float)
    c7.set_defaults(method="invoice/savePayment", save_builder="save_payment")

    c8 = leaf(c, "online-url", help="لینک فاکتور آنلاین (invoice/getOnlineInvoiceUrl)")
    c8.add_argument("--number", required=True); c8.add_argument("--type", required=True)
    c8.set_defaults(method="invoice/getOnlineInvoiceUrl", fixed={"number": "number"}, enum={"target": "type", "table": INVOICE_TYPES})

    c9 = leaf(c, "save-warehouse-receipt", help="ثبت حواله انبار فاکتور (invoice/SaveWarehouseReceipt)")
    c9.add_argument("--file", help="فایل JSON کامل receipt")
    c9.add_argument("--warehouse-code", required=True); c9.add_argument("--invoice-number", required=True)
    c9.add_argument("--invoice-type", required=True)
    c9.add_argument("--date"); c9.add_argument("--notes"); c9.add_argument("--project"); c9.add_argument("--freight", type=float)
    c9.add_argument("--items-json", help='JSON: [{"itemCode":"..","quantity":5}]')
    c9.add_argument("--delete-old-receipts", action="store_true")
    c9.set_defaults(save_builder="wh_invoice")

    c10 = leaf(c, "change-paid-status", help="تغییر وضعیت پرداخت (invoice/changePaidStatus)")
    c10.add_argument("--number", required=True); c10.add_argument("--type", required=True)
    c10.add_argument("--paid", required=True, choices=["true", "false"])
    c10.set_defaults(method="invoice/changePaidStatus", fixed={"number": "number"},
                     enum={"target": "type", "table": INVOICE_TYPES}, bools={"paid": "paid"})

    c11 = leaf(c, "change-sent-status", help="تغییر وضعیت ارسال (invoice/changeSentStatus)")
    c11.add_argument("--number", required=True); c11.add_argument("--type", required=True)
    c11.add_argument("--sent", required=True, choices=["true", "false"])
    c11.set_defaults(method="invoice/changeSentStatus", fixed={"number": "number"},
                     enum={"target": "type", "table": INVOICE_TYPES}, bools={"sent": "sent"})

    # ---------------- receipt ----------------
    p = sub.add_parser("receipt", help="دریافت و پرداخت (رسیدهای مالی و چک)")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست رسیدها (receipt/getReceipts)")
    c1.add_argument("--type", required=True, help="نوع: دریافت/پرداخت/درآمد/هزینه یا 1-6")
    add_queryinfo(c1)
    c1.set_defaults(method="receipt/getReceipts", qinfo=True, enum={"target": "type", "table": RECEIPT_TYPES})

    c2 = leaf(c, "get", help="دریافت رسید (receipt/get)")
    c2.add_argument("--number", required=True); c2.add_argument("--type", required=True)
    c2.set_defaults(method="receipt/get", fixed={"number": "number"}, enum={"target": "type", "table": RECEIPT_TYPES})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه (receipt/GetById)")
    c3.add_argument("--ids", required=True); c3.add_argument("--type", required=True)
    c3.set_defaults(method="receipt/GetById", idlist=True, enum={"target": "type", "table": RECEIPT_TYPES})

    c4 = leaf(c, "save", help="ثبت ساده رسید (receipt/save) — دریافت/پرداخت از/به یک شخص")
    c4.add_argument("--type", required=True, help="دریافت/پرداخت/درآمد/هزینه یا 1-6")
    c4.add_argument("--amount", required=True, type=float)
    c4.add_argument("--contact-code", help="کد شخص (برای نوع 1 و 2)")
    src = c4.add_mutually_exclusive_group()
    src.add_argument("--bank-code"); src.add_argument("--cash-code"); src.add_argument("--petty-cash-code")
    c4.add_argument("--account-path", help="مسیر حساب (برای نوع 3 و 4)")
    c4.add_argument("--number", help="شماره رسید (خالی = خودکار)")
    c4.add_argument("--date-time", help="تاریخ و ساعت")
    c4.add_argument("--project"); c4.add_argument("--description"); c4.add_argument("--bank-fee", type=float)
    c4.add_argument("--reference"); c4.add_argument("--currency"); c4.add_argument("--currency-rate", type=float)
    c4.set_defaults(save_builder="receipt_simple")

    c5 = leaf(c, "save2", help="ثبت پیشرفته رسید (receipt/save2) — چند قلم، چند تراکنش و چک")
    c5.add_argument("--type", required=True)
    c5.add_argument("--file", help="فایل JSON کامل (شامل items و transactions)")
    c5.add_argument("--items-json", help='JSON اقلام: [{"contactCode":"2","amount":5000000,"description":".."}] یا [{"account":".."}]')
    c5.add_argument("--transactions-json", help='JSON تراکنش‌ها: [{"amount":..,"bankCode":".."}] یا [{"amount":..,"check":{"number":"..","date":"..","amount":..,"sayyad":"..","bankName":"..","payerCode":2}}]')
    c5.add_argument("--number"); c5.add_argument("--date-time"); c5.add_argument("--description")
    c5.add_argument("--project"); c5.add_argument("--currency"); c5.add_argument("--currency-rate", type=float)
    c5.set_defaults(save_builder="receipt2")

    c6 = leaf(c, "delete", help="حذف رسید (receipt/delete)")
    c6.add_argument("--number", required=True); c6.add_argument("--type", required=True)
    c6.set_defaults(method="receipt/delete", fixed={"number": "number"}, enum={"target": "type", "table": RECEIPT_TYPES})

    # ---------------- warehouse ----------------
    p = sub.add_parser("warehouse", help="رسید و حواله انبار")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست رسید/حواله (warehouse/getReceipts)")
    c1.add_argument("--type", required=True, help="ورود/رسید=1 یا خروج/حواله=2")
    add_queryinfo(c1)
    c1.set_defaults(method="warehouse/getReceipts", qinfo=True, enum={"target": "type", "table": WAREHOUSE_TYPES})

    c2 = leaf(c, "get", help="دریافت رسید/حواله (warehouse/get)")
    c2.add_argument("--number", required=True)
    c2.set_defaults(method="warehouse/get", fixed={"number": "number"})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه (warehouse/GetById)")
    c3.add_argument("--ids", required=True)
    c3.set_defaults(method="warehouse/GetById", idlist=True)

    c4 = leaf(c, "save", help="ثبت رسید/حواله انبار (warehouse/save)")
    c4.add_argument("--file", help="فایل JSON کامل receipt")
    c4.add_argument("--warehouse-code", required=True)
    c4.add_argument("--receiving", action="store_true", help="رسید ورود (بدون آن = حواله خروج)")
    c4.add_argument("--items-json", required=True, help='JSON: [{"itemCode":"..","quantity":5}]')
    c4.add_argument("--number"); c4.add_argument("--invoice-number"); c4.add_argument("--invoice-type")
    c4.add_argument("--destination-warehouse-code", help="برای انتقال بین انبار")
    c4.add_argument("--date"); c4.add_argument("--notes"); c4.add_argument("--delivery"); c4.add_argument("--freight", type=float)
    c4.add_argument("--project"); c4.add_argument("--delete-old-receipts", action="store_true")
    c4.set_defaults(save_builder="wh_save")

    c5 = leaf(c, "delete", help="حذف رسید/حواله (warehouse/delete)")
    c5.add_argument("--number", required=True)
    c5.set_defaults(method="warehouse/delete", fixed={"number": "number"})

    # ---------------- document ----------------
    p = sub.add_parser("document", help="اسناد حسابداری (سند دستی دوطرفه)")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست اسناد (document/getDocuments)")
    add_queryinfo(c1)
    c1.set_defaults(method="document/getDocuments", qinfo=True)

    c2 = leaf(c, "get", help="دریافت سند (document/get)")
    c2.add_argument("--number", required=True)
    c2.set_defaults(method="document/get", fixed={"number": "number"})

    c3 = leaf(c, "save", help="ثبت سند حسابداری (document/save)")
    c3.add_argument("--file", help="فایل JSON کامل سند (پیشنهادی)")
    c3.add_argument("--json", help="JSON کامل سند به‌صورت رشته")
    c3.add_argument("--number"); c3.add_argument("--date"); c3.add_argument("--description")
    c3.add_argument("--project"); c3.add_argument("--status", help="0 پیش‌نویس / 1 تأییدشده")
    c3.add_argument("--lines-json",
                    help='JSON سطرهای سند: [{"accountPath":"دارایی ها:...:صندوق","amount":1000,"type":0,"description":"..","cashCode":"1"}] — type: 0 بدهکار / 1 بستانکار')
    c3.set_defaults(save_builder="document")

    c4 = leaf(c, "delete", help="حذف سند (document/delete)")
    c4.add_argument("--number", required=True)
    c4.set_defaults(method="document/delete", fixed={"number": "number"})

    # ---------------- discount ----------------
    p = sub.add_parser("discount", help="اقلام تخفیف‌دار")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست تخفیف‌ها (disCountItem/getItems)")
    add_queryinfo(c1)
    c1.set_defaults(method="disCountItem/getItems", qinfo=True)

    c2 = leaf(c, "get", help="دریافت تخفیف‌ها با فیلتر (disCountItem/get)")
    c2.add_argument("--contact-code"); c2.add_argument("--product-code"); c2.add_argument("--contact-path")
    c2.add_argument("--product-path"); c2.add_argument("--tag")
    c2.set_defaults(method="disCountItem/get",
                    optmap={"contactCode": "contact_code", "productCode": "product_code",
                            "contactPath": "contact_path", "productPath": "product_path", "tag": "tag"})

    c3 = leaf(c, "getbyid", help="دریافت با شناسه (disCountItem/getById)")
    c3.add_argument("--ids", required=True)
    c3.set_defaults(method="disCountItem/getById", idlist=True)

    c4 = leaf(c, "save", help="ثبت تخفیف (disCountItem/save)")
    c4.add_argument("--file"); c4.add_argument("--json")
    c4.add_argument("--title", help="عنوان (الزامی)"); c4.add_argument("--type", help="1 تا 6 (الزامی)")
    c4.add_argument("--percent", type=float); c4.add_argument("--amount", type=float)
    c4.add_argument("--valid-from"); c4.add_argument("--valid-to"); c4.add_argument("--tag")
    c4.set_defaults(save_builder="discount")

    c5 = leaf(c, "batchsave", help="ثبت گروهی تخفیف (disCountItem/batchSave)")
    c5.add_argument("--file", required=True)
    c5.set_defaults(method="disCountItem/batchSave", passthrough="items")

    c6 = leaf(c, "delete", help="حذف تخفیف (disCountItem/delete)")
    c6.add_argument("--ids", required=True, help="شناسه‌ها جدا با کاما")
    c6.set_defaults(method="disCountItem/delete", idlist=True)

    # ---------------- banktransfer ----------------
    p = sub.add_parser("banktransfer", help="انتقال بین بانکی/صندوق")
    c = p.add_subparsers(dest="action", required=True)

    c1 = leaf(c, "list", help="لیست انتقال‌ها (bankTransfer/getTransfers)")
    add_queryinfo(c1)
    c1.set_defaults(method="bankTransfer/getTransfers", qinfo=True)

    c2 = leaf(c, "get", help="دریافت انتقال (bankTransfer/get)")
    c2.add_argument("--number", required=True)
    c2.set_defaults(method="bankTransfer/get", fixed={"number": "number"})

    c3 = leaf(c, "save", help="ثبت انتقال (bankTransfer/save)")
    c3.add_argument("--file", help="فایل JSON کامل transfer")
    c3.add_argument("--from-amount", type=float); c3.add_argument("--to-amount", type=float)
    c3.add_argument("--from-bank"); c3.add_argument("--from-cash"); c3.add_argument("--from-petty-cash")
    c3.add_argument("--to-bank"); c3.add_argument("--to-cash"); c3.add_argument("--to-petty-cash")
    c3.add_argument("--date"); c3.add_argument("--description"); c3.add_argument("--project")
    c3.add_argument("--from-reference"); c3.add_argument("--to-reference")
    c3.add_argument("--from-transaction-fee", type=float); c3.add_argument("--to-transaction-fee", type=float)
    c3.set_defaults(save_builder="banktransfer")

    c4 = leaf(c, "delete", help="حذف انتقال (bankTransfer/delete)")
    c4.add_argument("--number", required=True)
    c4.set_defaults(method="bankTransfer/delete", fixed={"number": "number"})

    # ---------------- setting ----------------
    p = sub.add_parser("setting", help="تنظیمات: سال مالی، بانک‌ها، صندوق‌ها، پروژه‌ها، حساب‌ها و...")
    c = p.add_subparsers(dest="action", required=True)
    simple_settings = {
        "changes": ("setting/getChanges", "آخرین تغییرات (getChanges) — شروع با --start"),
        "fiscal-years": ("setting/getFiscalYears", "لیست سال‌های مالی"),
        "fiscal-year": ("setting/getFiscalYear", "سال مالی جاری"),
        "banks": ("setting/getBanks", "لیست بانک‌ها"),
        "cashes": ("setting/getCashes", "لیست صندوق‌ها"),
        "petty-cashes": ("setting/getPettyCashes", "لیست تنخواه‌گردان‌ها"),
        "currency": ("setting/GetCurrency", "واحد پول پیش‌فرض"),
        "warehouses": ("setting/getWarehouses", "لیست انبارها"),
        "product-categories": ("setting/getProductCategories", "درخت دسته‌بندی کالاها"),
        "service-categories": ("setting/getServiceCategories", "درخت دسته‌بندی خدمات"),
        "contact-categories": ("setting/getContactCategories", "درخت دسته‌بندی اشخاص"),
        "projects": ("setting/getProjects", "لیست پروژه‌ها"),
        "salesmen": ("setting/getSalesmen", "لیست فروشندگان"),
        "currency-table": ("setting/getCurrencyTable", "جدول نرخ ارزها"),
        "accounts": ("setting/getAccounts", "جدول حساب‌ها (کدینگ حسابداری)"),
        "price-lists": ("setting/getDefaultPriceList", "لیست‌های قیمت پیش‌فرض"),
        "business-info": ("setting/getBusinessInfo", "اطلاعات کسب‌وکار و اشتراک"),
        "get-change-hook": ("setting/GetChangeHook", "مشخصات وب‌هوک‌های تغییرات"),
    }
    for name, (method, help_text) in simple_settings.items():
        cp = leaf(c, name, help=help_text)
        if name == "changes":
            cp.add_argument("--start", type=int, help="شناسه شروع (آخرین Id دیده‌شده)")
        cp.set_defaults(method=method, start_flag=(name == "changes"))

    c2 = leaf(c, "set-currency-table", help="ذخیره جدول نرخ ارزها (setting/setCurrencyTable)")
    c2.add_argument("--file", required=True, help='JSON: [{"from":"USD","to":"IRR","rate":60000}]')
    c2.set_defaults(method="setting/setCurrencyTable", passthrough="table")

    c3 = leaf(c, "set-change-hook", help="تنظیم وب‌هوک تغییرات (setting/SetChangeHook)")
    c3.add_argument("--url", required=True, help="آدرس HTTPS (رشته خالی = حذف هوک)")
    c3.add_argument("--hook-password", help="رمز بررسی اصالت وب‌هوک")
    c3.add_argument("--index", type=int, choices=[1, 2, 3], default=1)
    c3.set_defaults(save_builder="change_hook")

    # ---------------- report ----------------
    p = sub.add_parser("report", help="گزارش‌های مالی")
    c = p.add_subparsers(dest="action", required=True)
    reports = {
        "balance-sheet": ("report/balanceSheet", "ترازنامه"),
        "debtors-creditors": ("report/debtorsCreditors", "بدهکاران و بستانکاران"),
        "inventory": ("report/inventory", "گزارش موجودی کالا"),
        "profit-loss": ("report/profitandlossStatement", "صورت سود و زیان"),
        "trial-balance": ("report/trialBalance", "تراز آزمایشی"),
    }
    for name, (method, help_text) in reports.items():
        cp = leaf(c, name, help=help_text)
        add_dates(cp)
        cp.add_argument("--project")
        cp.set_defaults(method=method)

    cp = leaf(c, "trial-balance-items", help="آیتم‌های تفصیل تراز آزمایشی")
    add_dates(cp); cp.add_argument("--project")
    cp.add_argument("--account-path", required=True, help="مسیر حساب، مثل 'دارایی ها:دارایی های جاری'")
    cp.set_defaults(method="report/trialBalanceItems")

    for name, method, help_text in (("bank", "report/bank", "گردش حساب بانک"),
                                    ("cash", "report/cash", "گردش حساب صندوق"),
                                    ("petty-cash", "report/pettyCash", "گردش تنخواه‌گردان")):
        cp = leaf(c, name, help=help_text)
        add_dates(cp); cp.add_argument("--project")
        cp.add_argument("--code", required=True, help="کد بانک/صندوق/تنخواه")
        cp.set_defaults(method=method)

    cp = leaf(c, "journal", help="دفتر روزنامه (report/journal)")
    add_dates(cp); cp.add_argument("--project")
    cp.add_argument("--take", type=int, help="حداکثر 1000 سطر در هر درخواست")
    cp.add_argument("--skip", type=int)
    cp.set_defaults(method="report/journal")

    # ---------------- inquiry ----------------
    p = sub.add_parser("inquiry", help="سیستم استعلام (کد ملی، شبا، کارت، کد پستی)")
    c = p.add_subparsers(dest="action", required=True)

    cp = leaf(c, "credit", help="تعداد توکن باقیمانده استعلام (inquiry/credit)")
    cp.set_defaults(method="inquiry/credit")

    inquiries = {
        "national-identity": ("inquiry/nationalIdentity", "استعلام کد ملی",
                              [("national-code", "nationalCode"), ("birth-date", "birthDate")]),
        "mobile-national-code": ("inquiry/checkMobileAndNationalCode", "تطابق موبایل و کد ملی",
                                 [("national-code", "nationalCode"), ("mobile", "mobile")]),
        "card-national-code": ("inquiry/checkCardAndNationalCode", "تطابق کارت و کد ملی",
                               [("national-code", "nationalCode"), ("card-number", "cardNumber"), ("birth-date", "birthDate")]),
        "iban-national-code": ("inquiry/checkIbanAndNationalCode", "تطابق شبا و کد ملی",
                               [("national-code", "nationalCode"), ("iban", "iban"), ("birth-date", "birthDate")]),
        "iban": ("inquiry/iban", "استعلام شبا", [("iban", "iban")]),
        "card": ("inquiry/card", "استعلام کارت", [("card-number", "cardNumber")]),
        "card-to-iban": ("inquiry/cardToIban", "تبدیل کارت به شبا", [("card-number", "cardNumber")]),
        "account-to-iban": ("inquiry/accountToIBAN", "تبدیل حساب به شبا",
                            [("account", "account"), ("bank", "bank")]),
        "postal-code": ("inquiry/postalCode", "استعلام کد پستی", [("postal-code", "postalCode")]),
    }
    for name, (method, help_text, fields) in inquiries.items():
        cp = leaf(c, name, help=help_text)
        for arg_name, param in fields:
            cp.add_argument("--" + arg_name, required=True)
        cp.set_defaults(method=method, param_map={p: a.replace("-", "_") for a, p in fields})

    # ---------------- call (متد خام) ----------------
    cp = leaf(sub, "call", help="فراخوانی خام هر متد API حسابفا (پوشش همه متدها)")
    cp.add_argument("method_path", help="مسیر متد مثل invoice/getInvoices یا setting/getBanks")
    cp.add_argument("--data", help='بدنه JSON روش: \'{"code":"0001"}\' یا @file.json یا - (stdin)')
    cp.set_defaults(raw_call=True)

    # ---------------- selftest ----------------
    cp = leaf(sub, "selftest", help="تست خودکار آفلاین (تبدیل تاریخ و منطق CLI)")
    cp.set_defaults(selftest=True)

    return parser


# ---------------------------------------------------------------------------
# سازنده‌های بدنه ثبت (save builders)
# ---------------------------------------------------------------------------
CAMEL_MAP = {
    "code": "code", "name": "name", "contact_type": "contactType", "first_name": "firstName",
    "last_name": "lastName", "company": "company", "national_code": "nationalCode",
    "economic_code": "economicCode", "mobile": "mobile", "phone": "phone", "email": "email",
    "address": "address", "city": "city", "state": "state", "postal_code": "postalCode",
    "tag": "tag", "note": "note", "node_family": "nodeFamily", "tax_type": "taxType",
    "item_type": "itemType", "barcode": "barcode", "unit": "unit", "sub_unit": "subUnit",
    "buy_price": "buyPrice", "sell_price": "sellPrice", "description": "description",
    "number": "number", "date": "date", "due_date": "dueDate", "contact_code": "contactCode",
    "invoice_type": "invoiceType", "status": "status", "project": "project",
    "salesman_code": "salesmanCode", "salesman_percent": "salesmanPercent",
    "currency": "currency", "currency_rate": "currencyRate", "reference": "reference",
    "type": "type", "amount": "amount", "transaction_number": "transactionNumber",
    "bank_code": "bankCode", "cash_code": "cashCode", "petty_cash_code": "pettyCashCode",
    "account_path": "accountPath", "date_time": "dateTime", "bank_fee": "bankFee",
    "transaction_fee": "transactionFee", "warehouse_code": "warehouseCode",
    "invoice_number": "invoiceNumber", "destination_warehouse_code": "destinationWarehouseCode",
    "notes": "notes", "delivery": "delivery", "freight": "freight", "receiving": "receiving",
    "title": "title", "percent": "percent", "valid_from": "validFrom", "valid_to": "validTo",
    "from_amount": "fromAmount", "to_amount": "toAmount", "from_bank": "fromBank",
    "from_cash": "fromCash", "from_petty_cash": "fromPettyCash", "to_bank": "toBank",
    "to_cash": "toCash", "to_petty_cash": "toPettyCash", "from_reference": "fromReference",
    "to_reference": "toReference", "from_transaction_fee": "fromTransactionFee",
    "to_transaction_fee": "toTransactionFee", "hook_password": "hookPassword", "url": "url",
}


def typed_object(args, keys):
    obj = {}
    for k in keys:
        val = getattr(args, k, None)
        if val is None or val is False:
            continue
        obj[CAMEL_MAP.get(k, k)] = num(val) if isinstance(val, float) else val
    return obj


DATE_KEYS = ("date", "dueDate", "dateTime", "validFrom", "validTo", "birthDate",
             "weddingDate", "membershipDate", "startDate", "endDate")


ENUM_KEYS = {
    "contactType": CONTACT_TYPES,
    "ContactType": CONTACT_TYPES,  # یافته تست زنده: سرور فقط این شکل را ذخیره می‌کند
    "itemType": ITEM_TYPES,
    "invoiceType": INVOICE_TYPES,
    "status": STATUS_TYPES,
}
# توجه: کلید "type" عمداً نرمال‌سازی نمی‌شود (در سطرهای سند معنای بدهکار/بستانکار دارد)


def normalize_object_dates(obj):
    """تبدیل خودکار تاریخ‌های شمسی و enum های فارسی داخل اشیای JSON بارگذاری‌شده."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in DATE_KEYS and isinstance(v, str) and v:
                obj[k] = normalize_date(v)
            elif k in ENUM_KEYS and v is not None and not isinstance(v, bool):
                try:
                    obj[k] = resolve_enum(v, ENUM_KEYS[k], k)
                except SystemExit:
                    pass  # مقدار نامعتبر را به‌صورت دست‌نخورده به سرور می‌فرستیم تا خطای API روشن باشد
            elif isinstance(v, (dict, list)):
                normalize_object_dates(v)
    elif isinstance(obj, list):
        for item in obj:
            normalize_object_dates(item)
    return obj


def build_save_payload(args):
    """ساخت بدنه متدهای save بر اساس نوع دستور."""
    kind = args.save_builder
    payload = {}

    def from_file_or_json():
        raw = args.json if getattr(args, "json", None) else ("@" + args.file if getattr(args, "file", None) else None)
        return normalize_object_dates(read_json_arg(args, raw)) if raw else None

    if kind == "contact":
        obj = from_file_or_json()
        if obj is None:
            obj = typed_object(args, ["code", "name", "first_name", "last_name", "company",
                                      "national_code", "economic_code", "mobile", "phone", "email",
                                      "address", "city", "state", "postal_code", "tag", "note",
                                      "node_family"])
            if args.contact_type is not None:
                ct = resolve_enum(args.contact_type, CONTACT_TYPES, "contactType")
                # یافته تست زنده ۱۴۰۵/۰۸/۲۴: سرور فیلد contactType را نادیده می‌گیرد و
                # نوع شخص را از وجود فیلد «company» نتیجه می‌گیرد (شرکت پر ⇒ حقوقی).
                obj["ContactType"] = ct
                obj["contactType"] = ct
            if args.tax_type is not None:
                obj["taxType"] = int(args.tax_type)
            for flag, key in (("is_customer", "isCustomer"), ("is_vendor", "isVendor"),
                              ("is_employee", "isEmployee"), ("is_shareholder", "isShareHolder")):
                if getattr(args, flag):
                    obj[key] = True
        elif isinstance(obj, dict) and "contactType" in obj and "ContactType" not in obj:
            obj["ContactType"] = obj["contactType"]  # جاوااسکریپت/فایل دستی کاربر
        if isinstance(obj, dict):
            ct = obj.get("ContactType", obj.get("contactType"))
            if ct == 2 and not obj.get("company"):
                sys.stderr.write("یادآوری (تست زنده ۱۴۰۵/۰۸/۲۴): سرور حسابفا نوع شخص را از فیلد company نتیجه می‌گیرد "
                                 "و فیلد contactType را نادیده می‌گیرد؛ برای ثبت شخص حقوقی فیلد company را پر کنید.\n")
        payload["contact"] = obj

    elif kind == "item":
        obj = from_file_or_json()
        if obj is None:
            obj = typed_object(args, ["code", "name", "barcode", "unit", "sub_unit", "buy_price",
                                      "sell_price", "node_family", "description", "tag"])
            if args.item_type is not None:
                obj["itemType"] = resolve_enum(args.item_type, ITEM_TYPES, "itemType")
            if args.tax_type is not None:
                obj["taxType"] = int(args.tax_type)
            if args.sales_taxable:
                obj["salesTaxable"] = True
            if args.purchase_taxable:
                obj["purchaseTaxable"] = True
        payload["item"] = obj

    elif kind == "invoice":
        obj = from_file_or_json()
        if obj is None:
            obj = typed_object(args, ["number", "contact_code", "project", "note", "tag",
                                      "salesman_code", "salesman_percent", "currency",
                                      "currency_rate", "reference"])
            if args.date:
                obj["date"] = normalize_date(args.date)
            if args.due_date:
                obj["dueDate"] = normalize_date(args.due_date)
            if args.invoice_type is not None:
                obj["invoiceType"] = resolve_enum(args.invoice_type, INVOICE_TYPES, "invoiceType")
            if args.status is not None:
                obj["status"] = resolve_enum(args.status, STATUS_TYPES, "status")
            items = read_json_arg(args, args.items_json) if args.items_json else None
            if items:
                obj["invoiceItems"] = normalize_object_dates(items)
            others = read_json_arg(args, args.others_json) if args.others_json else None
            if others:
                obj["others"] = others
        payload["invoice"] = obj

    elif kind == "save_payment":
        obj = typed_object(args, ["number", "amount", "contact_code", "bank_code", "cash_code",
                                  "petty_cash_code", "description", "project",
                                  "transaction_number", "transaction_fee", "currency", "currency_rate"])
        if args.date:
            obj["date"] = normalize_date(args.date)
        obj["type"] = resolve_enum(args.type, INVOICE_TYPES, "type")
        payload.update(obj)

    elif kind == "receipt_simple":
        obj = typed_object(args, ["number", "contact_code", "amount", "bank_code", "cash_code",
                                  "petty_cash_code", "account_path", "project", "description",
                                  "bank_fee", "reference", "currency", "currency_rate"])
        if args.date_time:
            obj["dateTime"] = normalize_date(args.date_time)
        obj["type"] = resolve_enum(args.type, RECEIPT_TYPES, "type")
        payload.update(obj)

    elif kind == "receipt2":
        obj = read_json_arg(args, "@" + args.file) if args.file else None
        if obj is not None:
            normalize_object_dates(obj)
        if obj is None:
            obj = typed_object(args, ["number", "description", "project", "currency", "currency_rate"])
            if args.date_time:
                obj["dateTime"] = normalize_date(args.date_time)
            items = read_json_arg(args, args.items_json) if args.items_json else []
            transactions = read_json_arg(args, args.transactions_json) if args.transactions_json else []
            obj["items"] = normalize_object_dates(items)
            obj["transactions"] = normalize_object_dates(transactions)
        obj["type"] = resolve_enum(args.type, RECEIPT_TYPES, "type")
        payload.update(obj)

    elif kind == "wh_invoice":  # invoice/SaveWarehouseReceipt
        obj = read_json_arg(args, "@" + args.file) if args.file else None
        if obj is not None:
            normalize_object_dates(obj)
        if obj is None:
            obj = typed_object(args, ["warehouse_code", "invoice_number", "notes", "freight", "project"])
            if args.date:
                obj["date"] = normalize_date(args.date)
            obj["invoiceType"] = resolve_enum(args.invoice_type, INVOICE_TYPES, "invoiceType")
            if not args.items_json:
                usage_error("اقلام حواله لازم است — با --items-json یا --file بدهید")
            obj["items"] = read_json_arg(args, args.items_json) or []
        payload["deleteOldReceipts"] = bool(args.delete_old_receipts)
        payload["receipt"] = obj

    elif kind == "wh_save":  # warehouse/save
        obj = read_json_arg(args, "@" + args.file) if args.file else None
        if obj is not None:
            normalize_object_dates(obj)
        if obj is None:
            obj = typed_object(args, ["number", "invoice_number", "warehouse_code",
                                      "destination_warehouse_code", "notes", "delivery",
                                      "freight", "project"])
            if args.date:
                obj["date"] = normalize_date(args.date)
            if args.invoice_type is not None:
                obj["invoiceType"] = resolve_enum(args.invoice_type, INVOICE_TYPES, "invoiceType")
            obj["receiving"] = bool(args.receiving)
            obj["items"] = read_json_arg(args, args.items_json) or []
        payload["deleteOldReceipts"] = bool(args.delete_old_receipts)
        payload["receipt"] = obj

    elif kind == "document":
        obj = from_file_or_json()
        if obj is None:
            obj = typed_object(args, ["number", "description", "project"])
            if args.date:
                obj["date"] = normalize_date(args.date)
            if args.status is not None:
                obj["status"] = resolve_enum(args.status, STATUS_TYPES, "status")
            lines = read_json_arg(args, args.lines_json) if args.lines_json else None
            if not lines:
                usage_error("سطرهای سند لازم است — با --lines-json یا --file بدهید (ساختار کامل در references/objects.md)")
            obj["transactions"] = lines
        payload["document"] = obj

    elif kind == "discount":
        obj = from_file_or_json()
        if obj is None:
            obj = typed_object(args, ["title", "percent", "amount", "tag"])
            if args.type is not None:
                obj["type"] = int(args.type)
            if args.valid_from:
                obj["validFrom"] = normalize_date(args.valid_from)
            if args.valid_to:
                obj["validTo"] = normalize_date(args.valid_to)
        payload["item"] = obj

    elif kind == "banktransfer":
        obj = read_json_arg(args, "@" + args.file) if args.file else None
        if obj is None:
            obj = typed_object(args, ["from_amount", "to_amount", "from_bank", "from_cash",
                                      "from_petty_cash", "to_bank", "to_cash", "to_petty_cash",
                                      "description", "project", "from_reference", "to_reference",
                                      "from_transaction_fee", "to_transaction_fee"])
            if args.date:
                obj["date"] = normalize_date(args.date)
        payload["transfer"] = obj

    elif kind == "change_hook":
        payload["url"] = args.url
        if args.hook_password:
            payload["hookPassword"] = args.hook_password
        payload["index"] = args.index

    else:
        usage_error("سازنده save ناشناخته: %s" % kind)
    return payload


# ---------------------------------------------------------------------------
# اجرای دستور
# ---------------------------------------------------------------------------
def fixed_payload(args):
    """ساخت بدنه برای متدهای fixed/idlist/enum/passthrough."""
    payload = {}
    for key, src in (getattr(args, "fixed", None) or {}).items():
        payload[key] = getattr(args, src)
    if getattr(args, "idlist", False):
        payload["idList"] = [int(x) for x in str(args.ids).replace(" ", "").split(",") if x != ""]
    enums = getattr(args, "enum", None)
    if enums:
        attr = enums["target"]
        payload[attr] = resolve_enum(getattr(args, attr), enums["table"], attr)
    for key, attr in (getattr(args, "bools", None) or {}).items():
        payload[key] = str(getattr(args, attr)).lower() == "true"
    for attr in getattr(args, "csv_fields", None) or []:
        raw = getattr(args, attr)
        if raw:
            payload[attr] = [x.strip() for x in str(raw).split(",") if x.strip()]
    for key, attr in (getattr(args, "optmap", None) or {}).items():
        val = getattr(args, attr, None)
        if val:
            payload[key] = val
    for key, attr in (getattr(args, "param_map", None) or {}).items():
        payload[key] = getattr(args, attr)
    if getattr(args, "start_flag", False) and getattr(args, "start", None) is not None:
        payload["start"] = args.start
    if getattr(args, "days_flag", False):
        if getattr(args, "show_all_accounts", False):
            payload["showAllAccounts"] = True
        payload["days"] = args.days
    if getattr(args, "qinfo", False):
        payload["queryInfo"] = build_queryinfo(args, getattr(args, "name_field", None))
    if getattr(args, "passthrough", False):
        payload[args.passthrough] = read_json_arg(args, "@" + args.file)
    return {k: v for k, v in payload.items() if v is not None}


def report_payload(args):
    """ساخت بدنه گزارش‌ها: startDate/endDate/project (+ accountPath/code/take/skip)."""
    payload = {}
    if getattr(args, "start_date", None):
        payload["startDate"] = normalize_date(args.start_date)
    if getattr(args, "end_date", None):
        payload["endDate"] = normalize_date(args.end_date)
    if getattr(args, "project", None):
        payload["project"] = args.project
    if getattr(args, "account_path", None):
        payload["accountPath"] = args.account_path
    if getattr(args, "code", None):
        payload["code"] = args.code
    if getattr(args, "take", None):
        payload["take"] = args.take
    if getattr(args, "skip", None):
        payload["skip"] = args.skip
    return payload


def run_selftest():
    failures = []
    pairs = [((1403, 1, 1), (2024, 3, 20)), ((1404, 1, 1), (2025, 3, 21)),
             ((1403, 12, 30), (2025, 3, 20)), ((1402, 12, 29), (2024, 3, 19)),
             ((1375, 10, 11), (1996, 12, 31)), ((1405, 8, 24), (2026, 11, 15))]
    for j, g in pairs:
        got = jalali_to_gregorian(*j)
        if got != g:
            failures.append("jalali_to_gregorian%s = %s (انتظار: %s)" % (j, got, g))
    if normalize_date("1404/08/23") != "2025-11-14":
        failures.append("normalize_date('1404/08/23') = %s" % normalize_date("1404/08/23"))
    if normalize_date("2025-11-14") != "2025-11-14":
        failures.append("normalize_date میلادی خراب است")

    t = tehran_today()
    if t.year < 2020:
        failures.append("tehran_today سال غیرمنطقی: %s" % t)

    class A:
        take, skip, sort_by, sort_desc, search, search_fields = 50, 10, "Name", True, "شرکت", "Name,Mobile"
        filter = ['Name:*:شرکت', 'Code:in:["1","2"]']
    qi = build_queryinfo(A)
    if qi.get("take") != 50 or qi.get("sortDesc") is not True:
        failures.append("queryInfo ناقص: %s" % qi)
    if qi.get("filters") != [{"property": "Name", "operator": "*", "value": "شرکت"},
                             {"property": "Code", "operator": "in", "value": ["1", "2"]}]:
        failures.append("فیلترها خراب: %s" % qi.get("filters"))

    class B:  # --search بدون --search-fields → فلتر شامل روی فیلد نام ماژول
        take, skip, sort_by, sort_desc, search, search_fields, filter = 20, 0, None, False, "آزمایشی", None, []
    qb = build_queryinfo(B, name_field="Name")
    if qb.get("filters") != [{"property": "Name", "operator": "*", "value": "آزمایشی"}] or "search" in qb:
        failures.append("ترجمه‌ی search به فلتر خراب: %s" % qb)

    class C:  # --search با تک‌فیلد --search-fields → فلتر روی همان فیلد
        take, skip, sort_by, sort_desc, search, search_fields, filter = 20, 0, None, False, "0912", "Mobile", []
    qc = build_queryinfo(C)
    if qc.get("filters") != [{"property": "Mobile", "operator": "*", "value": "0912"}] or "search" in qc:
        failures.append("ترجمه‌ی search با searchFields خراب: %s" % qc)

    checks = [(resolve_enum("فروش", INVOICE_TYPES, "t"), 0),
              (resolve_enum("purchase", INVOICE_TYPES, "t"), 1),
              (resolve_enum("دریافت", RECEIPT_TYPES, "t"), 1),
              (resolve_enum("هزینه", RECEIPT_TYPES, "t"), 4),
              (resolve_enum("service", ITEM_TYPES, "t"), 1)]
    for got, want in checks:
        if got != want:
            failures.append("resolve_enum: %s != %s" % (got, want))

    if failures:
        print("خودآزمایی ناموفق:")
        for f in failures:
            print("  ✗ " + f)
        sys.exit(1)
    print("خودآزمایی موفق: تبدیل تاریخ شمسی (به وقت تهران)، queryInfo، ترجمه‌ی search به فلتر و enum ها سالم هستند.")
    sys.exit(0)


def main():
    extracted, argv = extract_globals(sys.argv[1:])
    parser = build_parser()
    args = parser.parse_args(argv)

    if getattr(args, "selftest", False):
        run_selftest()

    # اعتبارنامه و تنظیمات عمومی: استخراج‌شده > متغیر محیطی > پیش‌فرض
    args.api_key = extracted.get("--api-key") or args.api_key or os.environ.get("HESABFA_API_KEY")
    args.login_token = extracted.get("--login-token") or args.login_token or os.environ.get("HESABFA_LOGIN_TOKEN")
    args.user_id = extracted.get("--user-id") or args.user_id or os.environ.get("HESABFA_USER_ID")
    args.password = extracted.get("--password") or args.password or os.environ.get("HESABFA_PASSWORD")
    if extracted.get("--year-id"):
        args.year_id = int(extracted["--year-id"])
    if extracted.get("--base-url"):
        args.base_url = extracted["--base-url"]
    if extracted.get("--timeout"):
        args.timeout = int(extracted["--timeout"])
    if extracted.get("--dry-run"):
        args.dry_run = True
    if extracted.get("--compact"):
        args.compact = True
    if extracted.get("--result"):
        args.result = True
    if extracted.get("--idempotency"):
        args.idempotency = True
    if extracted.get("--no-retry-rate-limit"):
        args.retry_rate_limit = False

    if getattr(args, "raw_call", False):
        data = read_json_arg(args, args.data) or {}
        envelope = api_call(args.method_path, data, args)
        finish(envelope, args)

    if getattr(args, "save_builder", None):
        payload = build_save_payload(args)
        method = {"contact": "contact/save", "item": "item/save", "invoice": "invoice/save",
                  "save_payment": "invoice/savePayment",
                  "receipt_simple": "receipt/save", "receipt2": "receipt/save2",
                  "wh_invoice": "invoice/SaveWarehouseReceipt", "wh_save": "warehouse/save",
                  "document": "document/save", "discount": "disCountItem/save",
                  "banktransfer": "bankTransfer/save", "change_hook": "setting/SetChangeHook"}[args.save_builder]
        envelope = api_call(method, payload, args)
        finish(envelope, args)

    payload = fixed_payload(args)
    if args.cmd == "report":
        payload = report_payload(args)
    envelope = api_call(args.method, payload, args)
    finish(envelope, args)


if __name__ == "__main__":
    main()
