#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tests/test_hesabfa.py — Tests for hesabfa CLI (offline self-test equivalent)
Run with:  python3 tests/test_hesabfa.py
Or:        python3 -m pytest tests/test_hesabfa.py -v
"""

import sys
import os

# Make sure the script can be imported
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from hesabfa import (
    jalali_to_gregorian,
    tehran_today,
    normalize_date,
    build_queryinfo,
    resolve_enum,
    INVOICE_TYPES,
    RECEIPT_TYPES,
    ITEM_TYPES,
    CONTACT_TYPES,
    WAREHOUSE_TYPES,
    STATUS_TYPES,
)


# ---------------------------------------------------------------------------
# jalali_to_gregorian
# ---------------------------------------------------------------------------
def test_jalali_to_gregorian():
    pairs = [
        ((1403, 1, 1), (2024, 3, 20)),
        ((1404, 1, 1), (2025, 3, 21)),
        ((1403, 12, 30), (2025, 3, 20)),
        ((1402, 12, 29), (2024, 3, 19)),
        ((1375, 10, 11), (1996, 12, 31)),
        ((1405, 8, 24), (2026, 11, 15)),
    ]
    failed = []
    for j, g in pairs:
        got = jalali_to_gregorian(*j)
        if got != g:
            failed.append(f"jalali_to_gregorian{j} = {got} (expected: {g})")
    assert not failed, "\n".join(f"  ✗ {f}" for f in failed) or "all pass"


# ---------------------------------------------------------------------------
# normalize_date
# ---------------------------------------------------------------------------
def test_normalize_date_jalali():
    assert normalize_date("1404/08/23") == "2025-11-14", "Jalali date conversion failed"
    assert normalize_date("2025-11-14") == "2025-11-14", "Gregorian passthrough failed"
    assert normalize_date("1404/08/23 10:30:00") == "2025-11-14 10:30:00", "DateTime passthrough failed"
    assert normalize_date("today") == tehran_today().isoformat(), "today resolution failed"
    assert normalize_date("امروز") == tehran_today().isoformat(), "'امروز' resolution failed"


def test_normalize_date_invalid():
    """Invalid dates should raise SystemExit (exit code 4 via cli convention)."""
    for bad in ("not-a-date", "abc/xyz", ""):
        try:
            normalize_date(bad)
            assert False, f"Expected SystemExit for {bad!r}"
        except SystemExit as e:
            assert e.code == 4, f"Expected code 4, got {e.code!r}"


# ---------------------------------------------------------------------------
# tehran_today
# ---------------------------------------------------------------------------
def test_tehran_today():
    t = tehran_today()
    assert isinstance(t, type(tehran_today()))  # date type
    assert t.year >= 2020, f"tehran_today returned unexpected year: {t.year}"
    assert t.month in range(1, 13)
    assert t.day in range(1, 32)


# ---------------------------------------------------------------------------
# build_queryinfo
# ---------------------------------------------------------------------------
def test_queryinfo_basic():
    class Args:
        take = 50; skip = 10; sort_by = "Name"; sort_desc = True
        search = "شرکت"; search_fields = None; filter = []
    qi = build_queryinfo(Args, name_field="Name")
    assert qi["take"] == 50
    assert qi["skip"] == 10
    assert qi["sortBy"] == "Name"
    assert qi["sortDesc"] is True
    # search without search_fields → converted to filter on name_field
    assert qi["filters"] == [{"property": "Name", "operator": "*", "value": "شرکت"}]
    assert "search" not in qi, "search should not appear when filtered to one field"


def test_queryinfo_search_with_fields():
    class Args:
        take = 20; skip = 0; sort_by = None; sort_desc = False
        search = "0912"; search_fields = "Mobile"; filter = []
    qi = build_queryinfo(Args)
    assert qi["filters"] == [{"property": "Mobile", "operator": "*", "value": "0912"}]
    assert "search" not in qi


def test_queryinfo_filters():
    class Args:
        take = 20; skip = 0; sort_by = None; sort_desc = False
        search = None; search_fields = None
        filter = ['Name:*:شرکت', 'Code:in:["1","2"]']
    qi = build_queryinfo(Args)
    expected = [
        {"property": "Name", "operator": "*", "value": "شرکت"},
        {"property": "Code", "operator": "in", "value": ["1", "2"]},
    ]
    assert qi["filters"] == expected, f"filters mismatch: {qi.get('filters')}"


def test_queryinfo_no_search():
    class Args:
        take = 20; skip = 0; sort_by = None; sort_desc = False
        search = None; search_fields = None; filter = None
    qi = build_queryinfo(Args)
    assert "filters" not in qi
    assert "search" not in qi


# ---------------------------------------------------------------------------
# resolve_enum
# ---------------------------------------------------------------------------
def test_resolve_enum_invoice():
    assert resolve_enum("فروش", INVOICE_TYPES, "t") == 0
    assert resolve_enum("purchase", INVOICE_TYPES, "t") == 1
    assert resolve_enum("برگشت از فروش", INVOICE_TYPES, "t") == 2
    assert resolve_enum("ضایعات", INVOICE_TYPES, "t") == 4
    assert resolve_enum("0", INVOICE_TYPES, "t") == 0
    assert resolve_enum(0, INVOICE_TYPES, "t") == 0


def test_resolve_enum_receipt():
    assert resolve_enum("دریافت", RECEIPT_TYPES, "t") == 1
    assert resolve_enum("پرداخت", RECEIPT_TYPES, "t") == 2
    assert resolve_enum("درآمد", RECEIPT_TYPES, "t") == 3
    assert resolve_enum("هزینه", RECEIPT_TYPES, "t") == 4
    assert resolve_enum("receive", RECEIPT_TYPES, "t") == 1
    assert resolve_enum("expense", RECEIPT_TYPES, "t") == 4


def test_resolve_enum_item():
    assert resolve_enum("کالا", ITEM_TYPES, "t") == 0
    assert resolve_enum("service", ITEM_TYPES, "t") == 1
    assert resolve_enum("خدمت", ITEM_TYPES, "t") == 1


def test_resolve_enum_contact():
    assert resolve_enum("حقیقی", CONTACT_TYPES, "t") == 1
    assert resolve_enum("حقوقی", CONTACT_TYPES, "t") == 2
    assert resolve_enum("unknown", CONTACT_TYPES, "t") == 0


def test_resolve_enum_warehouse():
    assert resolve_enum("رسید", WAREHOUSE_TYPES, "t") == 1
    assert resolve_enum("حواله", WAREHOUSE_TYPES, "t") == 2
    assert resolve_enum("ورود", WAREHOUSE_TYPES, "t") == 1
    assert resolve_enum("خروج", WAREHOUSE_TYPES, "t") == 2


def test_resolve_enum_status():
    assert resolve_enum("پیش‌نویس", STATUS_TYPES, "t") == 0
    assert resolve_enum("تأییدشده", STATUS_TYPES, "t") == 1
    assert resolve_enum("draft", STATUS_TYPES, "t") == 0


def test_resolve_enum_invalid():
    try:
        resolve_enum("nonexistent_xyz", INVOICE_TYPES, "t")
        assert False, "Expected SystemExit for invalid enum value"
    except SystemExit as e:
        assert e.code == 4


def test_resolve_enum_none():
    assert resolve_enum(None, INVOICE_TYPES, "t") is None


# ---------------------------------------------------------------------------
# mask_creds (dry-run security)
# ---------------------------------------------------------------------------
def test_mask_creds():
    from hesabfa import mask_creds
    body = {"apiKey": "abcdefghijklmnop", "loginToken": "secret123", "other": "visible"}
    masked = mask_creds(body)
    assert masked["apiKey"] == "abcd…"
    assert masked["loginToken"] == "secr…"
    assert masked["other"] == "visible"
    assert "password" not in masked  # password not present


def test_mask_creds_password():
    from hesabfa import mask_creds
    body = {"password": "mypassword"}
    masked = mask_creds(body)
    assert masked["password"] == "****"


# ---------------------------------------------------------------------------
# is_mutation
# ---------------------------------------------------------------------------
def test_is_mutation():
    from hesabfa import is_mutation
    assert is_mutation("contact/save") is True
    assert is_mutation("contact/delete") is True
    assert is_mutation("invoice/getInvoices") is False
    assert is_mutation("setting/getChanges") is False  # special exception
    assert is_mutation("setting/setChangeHook") is True
    assert is_mutation("report/trialBalance") is False


# ---------------------------------------------------------------------------
# num helper
# ---------------------------------------------------------------------------
def test_num():
    from hesabfa import num
    assert num(5) == 5
    assert num(5.0) == 5
    assert num(5.7) == 5.7
    assert num(None) is None
    assert num("100") == 100
    assert num("abc") == "abc"


# ---------------------------------------------------------------------------
# read_json_arg
# ---------------------------------------------------------------------------
def test_read_json_arg_inline():
    from hesabfa import read_json_arg
    class Args:
        pass
    result = read_json_arg(Args(), '{"key": 1}')
    assert result == {"key": 1}


def test_read_json_arg_empty():
    from hesabfa import read_json_arg
    class Args:
        pass
    assert read_json_arg(Args(), None) is None


# ---------------------------------------------------------------------------
# Summary runner (run all tests, print pass/fail)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import traceback
    _all = [v for k, v in locals().items() if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for fn in _all:
        try:
            fn()
            print(f"  ✓ {fn.__name__}")
            passed += 1
        except Exception as exc:
            print(f"  ✗ {fn.__name__}: {exc}")
            traceback.print_exc()
            failed += 1
    print(f"\nResults: {passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
