# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.1.0] — 2026-11-14

### Added
- پوشش کامل ۹۲ متد رسمی API حسابفا در ۱۲ ماژول
- CLI استاندارد پایتون با پشتیبانی از تمامی پرچم‌ها
- تبدیل خودکار تاریخ شمسی به میلادی (الگوریتم Jalali→Gregorian)
- پذیرش enum ها با نام فارسی/انگلیسی (faktoors, receipt, item, contact, warehouse, status)
- ترجمه خودکار `--search` به فلتر شامل (`*`) روی فیلد نام ماژول
- پشتیبانی از `--filter` چندگانه (AND ترکیبی)
- سازنده‌های بدنه ثبت برای تمام ۱۱ ماژول mutate
- حالت `--dry-run` با ماسک‌کردن خودکار کلیدها در خروجی
- تلاش مجدد خودکار در خطای 101 (TooManyRequests)
- پشتیبانی از stdin (`-`) و فایل‌های JSON (`@path` و `-`)
- `requestUniqueId` خودکار برای متدهای mutation با `--idempotency`
- تست خودکار آفلاین (`selftest`) با تست تبدیل تاریخ، queryInfo و enum ها

### Fixed
- سرور حسابفا فیلد `contactType` را نادیده می‌گیرد؛ CLI هشدار می‌دهد و از `company` نتیجه می‌گیرد (تست زنده ۱۴۰۵/۰۸/۲۴)
- سرور کلید `search` در queryInfo را نادیده می‌گیرد؛ CLI به طور خودکار به فلتر `*` ترجمه می‌کند (تست زنده ۱۴۰۵/۰۸/۲۴)
- تاریخ «امروز»/`today` به وقت Asia/Tehran حل می‌شود، نه ساعت ماشین اجرا

### Changed
- خروجی به‌طور پیش‌فرض JSON مرتب (indent=2); پرچم `--compact` تک‌خطی می‌کند
- پرچم‌های عمومی (apiKey, loginToken, ...) قابل نوشتن در هر موقعیت خط فرمان

## [1.0.0] — 2026-05-01

### Added
- نسخه اولیه: ۷۰ متد از ۹۲ متد API (ماژول‌های contact, item, invoice, receipt, document, setting, report)
- پشتیبانی پایه تبدیل تاریخ شمسی/ميلادی
- تست خودکار اولیه

[Unreleased]: https://github.com/[REPO]/hesabfa-accounting/compare/v1.1.0...HEAD
[1.1.0]: https://github.com/[REPO]/hesabfa-accounting/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/[REPO]/hesabfa-accounting/releases/tag/v1.0.0
